#include <bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int n, r;
        cin >> n >> r;
        int a[n], b[r], a1[r];
        fill(a, a + n, 0);
        for (int i = 0; i < r; ++i)
            cin >> b[i];
        for (int i = 0; i < r; ++i)
            a[b[i] - 1] = 1;
        bool val = prev_permutation(a, a + n);
        if (val == false)
            cout << r << endl;
        else
        {
            int ok = 0, cnt = 0;
            for (int i = 0; i < n; ++i)
                if (a[i])
                    a1[ok++] = i + 1;
            int u = 0, d = 0;
            while (u < r and d < r)
            {
                if (a1[u] == b[d])
                {
                    cnt++;
                    u++;
                    d++;
                }
                else if (a1[u] > b[d])
                    d++;
                else
                    u++;
            }
            cout << r - cnt << endl;
        }
    }
}