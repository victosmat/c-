#include <bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        string s;
        cin >> s;
        stack<int> a;
        for (int i = 0; i < s.length(); i++)
        {
            if (s[i] == '(')
                a.push(i);
            else if (s[i] == ')')
            {
                int val = a.top();
                a.pop();
                if (val == 0)
                    continue;
                else if (s[val - 1] == '+')
                    continue;
                else if (s[val - 1] == '-')
                {
                    for (int j = val + 1; j < i; j++)
                        if (s[j] == '+')
                            s[j] = '-';
                        else if (s[j] == '-')
                            s[j] = '+';
                }
            }
        }
        for (int i = 0; i < s.length(); i++)
            if (s[i] != '(' && s[i] != ')')
                cout << s[i];
        cout << endl;
    }
}
