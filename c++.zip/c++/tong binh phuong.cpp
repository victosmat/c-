#include <bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    cin >> t;
    long long a[100];
    for (int i = 0; i < 100; i++)
        a[i] = (i + 1) * (i + 1);
    while (t--)
    {
        cout << a[99] << endl;
    }
}