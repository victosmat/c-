#include <bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int n;
        cin >> n;
        queue<int> pq;
        while (n--)
        {
            int a;
            cin >> a;
            if (a == 1)
                cout << pq.size() << endl;
            else if (a == 2)
            {
                if (pq.empty())
                    cout << "YES" << endl;
                else
                    cout << "NO" << endl;
            }
            else if (a == 3)
            {
                int b;
                cin >> b;
                pq.push(b);
            }
            else if (a == 4)
            {
                if (!pq.empty())
                    pq.pop();
            }
            else if (a == 5)
            {
                if (!pq.empty())
                    cout << pq.front() << endl;
                else
                    cout << "-1" << endl;
            }
            else
            {
                if (!pq.empty())
                    cout << pq.back() << endl;
                else
                    cout << "-1" << endl;
            }
        }
    }
}