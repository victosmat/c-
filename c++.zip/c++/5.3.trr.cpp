//Xây dựng cây bao trùm bé nhất theo Prim
#include <iostream>
#define MAX 100
using namespace std;
struct edg
{
    int dau, cuoi, h;
};

class dothi
{
    int n, a[MAX][MAX], ne, atree[MAX][MAX];
    edg graph[MAX], tree[MAX];

public:
    int s;
    bool chuaxet[MAX];
    void readdata();
    void init();
    void dfstree(int u); //dfstree: duyet dfs tren cay
    void bubblesort();
    void prim(int s);
};

void dothi::readdata()
{
    cin >> n >> s;
    ne = 0;
    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= n; j++)
        {
            cin >> a[i][j];
            if ((a[i][j] > 0) && (i < j))
            { //(i,j) la 1 canh
                ne++;
                graph[ne].dau = i;
                graph[ne].cuoi = j;
                graph[ne].h = a[i][j];
            }
        }
}

void dothi::init()
{
    for (int i = 1; i <= n; i++)
        chuaxet[i] = true;
}

void dothi::dfstree(int u)
{
    chuaxet[u] = false;
    for (int i = 1; i <= n; i++)
        if ((atree[u][i] == 1) && (chuaxet[i] == true))
            dfstree(i);
}

void dothi::bubblesort()
{
    for (int i = 1; i < ne; i++)
        for (int j = ne; j >= i + 1; j--)
            if (graph[j].h < graph[j - 1].h)
                swap(graph[j], graph[j - 1]);
}

void dothi::prim(int s)
{
    int dH = 0;
    int net = 0;
    int connected;
    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= n; j++)
            atree[i][j] = 0;
    bubblesort();
    while (net != n - 1)
    { //lap cho den khi du so canh
        connected = 0;
        for (int i = 1; i <= ne; i++)
        { //moi lan lay 1 canh trong so be nhat trong so cac canh co 1 dau thuoc VH, 1 dau thuoc V
            init();
            dfstree(s); //trang thai chuaxet[] cua cac dinh tren cay (thuoc VH) se doi tu true -> false, cac dinh ko thuoc cay, chuaxet[] van la true
            int dau = graph[i].dau, cuoi = graph[i].cuoi;
            if (chuaxet[dau] != chuaxet[cuoi])
            { //canh i thoa man: 1 dau thuoc VH, mot dau thuoc V
                net++;
                tree[net].dau = dau;
                tree[net].cuoi = cuoi;
                dH += graph[i].h;
                atree[dau][cuoi] = atree[cuoi][dau] = 1;
                connected = 1;
                break;
            }
        }
        if (connected == 0)
        { //Do thi khong lien thong
            cout << "\nDo thi khong lien thong";
            return;
        }
    }
    cout << "dH = " << dH << endl;
    for (int i = 1; i <= net; i++)
        cout << tree[i].dau << "   " << tree[i].cuoi << endl;
}

int main()
{
    dothi g;
    g.readdata();
    g.prim(g.s);
}