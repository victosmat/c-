#include <bits/stdc++.h>
using namespace std;
#define N 123456789
typedef long long ll;

ll pow(ll n)
{
    if (n == 1)
        return 2;
    else
    {
        ll tmp = pow(n / 2) % N;
        if (n % 2 == 0)
            return (tmp * tmp) % N;
        else
            return (tmp * tmp * 2) % N;
    }
}

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        ll n;
        cin >> n;
        cout << pow(n - 1) << endl;
    }
}