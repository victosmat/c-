#include <bits/stdc++.h>
using namespace std;
int a[20], dem = 0, n;
bool Ok(int x, int y)
{
    for (int i = 1; i < x; i++)
        if (a[i] == y || abs(i - x) == abs(a[i] - y))
            return false;
    return true;
}
void Try(int i, int n)
{
    for (int j = 1; j <= n; j++)
    {
        if (Ok(i, j) == true)
        {
            a[i] = j;
            if (i == n)
                dem++;
            Try(i + 1, n);
        }
    }
}

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        dem = 0;
        memset(a,0, sizeof a);
        cin >> n;
        Try(1, n);
        cout << dem << endl;
    }
}