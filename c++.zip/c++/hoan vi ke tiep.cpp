#include <bits/stdc++.h>
using namespace std;
int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int n;
        cin >> n;
        int a[n];
        for (int i = 0; i < n; i++)
            cin >> a[i];
        int i = n - 2;
        while (a[i] > a[i + 1] && i >= 0)
            i--;
        if (i == -1)
            for (int k = 0; k < n; k++)
                cout << k + 1 << " ";
        else
        {
            int k = n - 1;
            while (a[i] > a[k])
                k--;
            swap(a[i], a[k]);
            int l = i + 1, r = n - 1;
            while (l < r)
            {
                swap(a[l], a[r]);
                l++, r--;
            }
            for (int i = 0; i < n; i++)
                cout << a[i] << " ";
        }
        cout << endl;
    }
}