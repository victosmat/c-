#include <bits/stdc++.h>
using namespace std;

int sum, a[100], b[100], n, test, t, check = 0;

void Try(int k)
{
    for (int i = 1; i >= 0; i--)
    {
        a[k] = i;
        if (k == n - 1)
        {
            int sum = 0;
            for (int j = 0; j < n; j++)
                if (a[j] == 1)
                    sum += b[j];
            if (sum == test)
            {
                check = 1;
                cout << "[";
                for (int j = 0; j < n; j++)
                {
                    if (a[j] == 1)
                    {
                        cout << b[j];
                        sum -= b[j];
                        if (sum > 0)
                            cout << " ";
                    }
                }
                cout << "] ";
            }
        }
        else
            Try(k + 1);
    }
}
int main()
{
    cin >> t;
    while (t--)
    {
        check = 0;
        cin >> n >> test;
        for (int i = 0; i < n; i++)
            cin >> b[i];
        sort(b, b + n);
        Try(0);
        if (check == 0)
            cout << -1;
        cout << endl;
    }
}