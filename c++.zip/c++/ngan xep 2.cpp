#include <bits/stdc++.h>
using namespace std;

int main()
{
    stack<int> s;
    int t;
    cin >> t;
    while (t--)
    {
        string str;
        cin >> str;
        if (str == "PUSH")
        {
            int n;
            cin >> n;
            s.push(n);
        }
        else if (str == "POP")
        {
            if (s.empty())
                continue;
            else
                s.pop();
        }
        else if (str == "PRINT")
        {
            if (s.empty())
                cout << "NONE" << endl;
            else
                cout << s.top() << endl;
        }
    }
}