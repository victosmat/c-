#include <bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        string a, b;
        int k;
        cin >> k >> a >> b;
        while (a.length() > b.length())
            b = '0' + b;
        while (b.length() > a.length())
            a = '0' + a;
        string str = "";
        int exp = 0;
        for (int i = a.length() - 1; i >= 0; i--)
        {
            int s = a[i] - '0' + b[i] - '0' + exp;
            if (s >= k)
            {
                str += (s - k + '0');
                exp = 1;
            }
            else
            {
                str += s + '0';
                exp = 0;
            }
        }
        if (exp == 1)
            str += exp + '0';
        reverse(str.begin(), str.end());
        cout << str << endl;
    }
}