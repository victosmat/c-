#include <bits/stdc++.h>
using namespace std;

vector<int> a[1005];
bool chuaxet[1005];
int val[1005], check = 0;
long v, e, s, t;
int x, y;

void BFS(int s)
{
    queue<int> pq;
    pq.push(s);
    while (!pq.empty())
    {
        int u = pq.front();
        pq.pop();
        chuaxet[u] = false;
        if (u == t)
        {
            check = 1;
            vector<int> A;
            int a = t;
            while (a != s)
            {
                A.push_back(a);
                a = val[a];
            }
            A.push_back(a);
            for (int i = A.size() - 1; i >= 0; i--)
                cout << A[i] << " ";
            cout << endl;
        }
        for (int i = 0; i < a[u].size(); i++)
        {
            if (chuaxet[a[u][i]])
            {
                chuaxet[a[u][i]] = false;
                val[a[u][i]] = u;
                pq.push(a[u][i]);
            }
        }
    }
}

void init()
{
    for (int i = 1; i <= v; i++)
        chuaxet[i] = true;
    for (int i = 1; i <= v; i++)
        a[i].clear();
}

int main()
{
    int test;
    cin >> test;
    while (test--)
    {
        cin >> v >> e >> s >> t;
        init();
        for (long i = 0; i < e; i++)
        {
            cin >> x >> y;
            a[x].push_back(y);
        }
        BFS(s);
        if (!check)
            cout << -1 << endl;
        check = 0;
    }
}