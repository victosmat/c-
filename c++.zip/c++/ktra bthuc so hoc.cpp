#include <bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        string str;
        cin >> str;
        stack<char> s;
        int dem = 0;
        for (int i = 0; i < str.length(); i++)
        {
            if (str[i] == ')')
            {
                char test = s.top();
                s.pop();
                int check = 1;
                while (test != '(')
                {
                    if (test == '+' || test == '-' || test == '*' || test == '/')
                        check = 0;
                    test = s.top();
                    s.pop();
                }
                if (check)
                {
                    dem = 1;
                    cout << "Yes" << endl;
                    break;
                }
            }
            else
                s.push(str[i]);
        }
        if (dem == 0)
            cout << "No" << endl;
    }
}