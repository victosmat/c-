#include <bits/stdc++.h>
using namespace std;

struct PhanSo
{
    long long tu;
    long long mau;
} p;

void nhap(PhanSo &p)
{
    cin >> p.tu >> p.mau;
}

void in(PhanSo &P)
{
    int a = P.tu;
    int b = P.mau;
    if (a % b == 0)
        cout << a / b;
    else
        cout << a << "/" << b;
}

void RutGon(PhanSo &P)
{
    int ans = __gcd(P.tu, P.mau);
    P.tu /= ans;
    P.mau /= ans;
}

int main()
{
    struct PhanSo p;
    nhap(p);
    RutGon(p);
    in(p);
    return 0;
}