#include <bits/stdc++.h>
using namespace std;

long long a[100], n, k;

int val(long long n, long long k)
{
    if (n == 0)
        return 0;
    if (n == 1)
        return 1;
    if (k <= a[n - 2])
        return val(n - 2, k);
    else
        return val(n + 1, k - a[n - 2]);
}

int main()
{
    int t;
    cin >> t;
    a[0] = 1;
    a[1] = 1;
    for (int i = 2; i < 93; i++)
        a[i] = a[i - 1] + a[i - 2];
    while (t--)
    {
        cin >> n >> k;
        cout << val(n, k) << endl;
    }
}