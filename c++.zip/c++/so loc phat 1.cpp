#include <bits/stdc++.h>
using namespace std;

void sinh(string a[], int n, int i)
{
    if (i == n)
    {
        for (int i = 0; i < n; i++)
            cout << a[i];
        cout << " ";
        return;
    }
    a[i] = "8";
    sinh(a, n, i + 1);
    a[i] = "6";
    sinh(a, n, i + 1);
}

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int n;
        cin >> n;
        string a[n];
        while (n > 0)
        {
            sinh(a, n, 0);
            n--;
        }
        cout << endl;
    }
}