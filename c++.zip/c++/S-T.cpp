#include <bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int s, t;
        cin >> s >> t;
        int dp[10001] = {0};
        for (int i = 1; i <= t; i++)
            if (i <= s)
                dp[i] = s - i;
            else if (i % 2 != 0)
                dp[i] = dp[(i + 1) / 2] + 2;
            else
                dp[i] = dp[i / 2] + 1;
        cout << dp[t] << endl;
    }
}