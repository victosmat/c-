#include <bits/stdc++.h>
#define ll long long
using namespace std;

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        string s;
        cin >> s;
        stack<long long> a;
        for (int i = 0; i < s.length(); i++)
        {
            if (s[i] == '+' || s[i] == '-' || s[i] == '*' || s[i] == '/')
            {
                long long s1 = a.top();
                a.pop();
                long long s2 = a.top();
                a.pop();
                long long tmp;
                if (s[i] == '+')
                    tmp = s1 + s2;
                if (s[i] == '-')
                    tmp = s2 - s1;
                if (s[i] == '*')
                    tmp = s1 * s2;
                if (s[i] == '/')
                    tmp = s2 / s1;
                a.push(tmp);
            }
            else
                a.push((long long)(s[i] - '0'));
        }
        cout << a.top() << endl;
    }
}