#include <bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int n;
        cin >> n;
        int a[n], b[n];
        for (int i = 0; i < n; i++)
        {
            cin >> a[i];
            b[i] = a[i];
        }
        int count = 1;
        for (int i = 1; i < n; i++)
            if (a[i] + b[i - 1] > a[i])
                b[i] = a[i] + b[i - 1];
        int max = INT_MIN;
        // cout << *max_element(b, b + n) << "\n";
        for (int i = 1; i < n; i++)
            if (b[i] > max)
                max = b[i];
        cout << max << endl;
    }
}