#include <bits/stdc++.h>
#define ll long long
using namespace std;

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int n;
        cin >> n;
        ll a[n], s = INT_MIN;
        for (int i = 1; i <= n; i++)
            cin >> a[i];
        stack<int> q;
        q.push(0);
        a[0] = 0, a[n + 1] = 0;
        int i = 1;
        while (i <= n + 1 && !q.empty())
        {
            if (a[q.top()] < a[i])
                q.push(i++);
            else
            {
                int val = q.top();
                q.pop();
                if (!q.empty())
                    s = max(s, a[val] * (i - q.top() - 1));
            }
        }
        cout << s << endl;
    }
}