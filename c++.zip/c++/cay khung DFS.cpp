#include <bits/stdc++.h>
using namespace std;

struct DS_canh
{
    int dau;
    int cuoi;
};
DS_canh T[1003];

int v, e, a, b, u, j;
vector<int> ke[1003];
bool chuaxet[1003];

void Tree_BFS(int u)
{
    queue<int> pq;
    chuaxet[u] = false;
    pq.push(u);
    while (!pq.empty())
    {
        int s = pq.front();
        pq.pop();
        for (int i = 0; i < ke[s].size(); i++)
        {
            if (chuaxet[ke[s][i]])
            {
                T[j].dau = s;
                T[j].cuoi = ke[s][i];
                j++;
                pq.push(ke[s][i]);
                chuaxet[ke[s][i]] = false;
            }
        }
    }
}

void init()
{
    memset(chuaxet, true, sizeof(chuaxet));
    for (int i = 1; i <= v; i++)
    {
        ke[i].clear();
        T[i].dau = 0;
        T[i].cuoi = 0;
    }
    j = 1;
}

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        cin >> v >> e >> u;
        init();
        for (int i = 0; i < e; i++)
        {
            cin >> a >> b;
            ke[a].push_back(b);
            ke[b].push_back(a);
        }
        Tree_BFS(u);
        bool check = true;
        for (int i = 1; i <= v; i++)
            if (chuaxet[i])
                check = false;
        if (!check)
            cout << -1 << endl;
        else
            for (int i = 1; i < j; i++)
                cout << T[i].dau << " " << T[i].cuoi << endl;
    }
}