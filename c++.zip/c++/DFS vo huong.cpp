#include <bits/stdc++.h>
using namespace std;

int a[1001][1001];

int n, m, chuaxet[1001], u, v, s;

void DFS(int u)
{
    cout << u << " ";
    chuaxet[u] = false;
    for (int v = 1; v <= n; v++)
        if (a[u][v] == 1 && chuaxet[v] == true)
            DFS(v);
}

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        cin >> n >> m >> s;
        for (int i = 1; i <= n; i++)
            for (int j = 1; j <= n; j++)
                a[i][j] = 0;

        for (int i = 1; i <= m; i++)
        {
            cin >> u >> v;
            a[u][v] = 1;
            a[v][u] = 1;
        }

        for (int i = 1; i <= n; i++)
            chuaxet[i] = 1;
        DFS(s);
        cout << endl;
    }
}