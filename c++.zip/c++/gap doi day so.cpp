#include <bits/stdc++.h>
#define ll long long
using namespace std;

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        ll n, k;
        cin >> n >> k;
        if (n == 1)
        {
            cout << 1 << endl;
            continue;
        }
        else
        {
            ll a = pow(2, n) / 2;
            while (n--)
            {
                if (k == a)
                {
                    k = n + 1;
                    break;
                }
                if (k > a)
                    k = a * 2 - k;
                a /= 2;
            }
            cout << k << endl;
        }
    }
}