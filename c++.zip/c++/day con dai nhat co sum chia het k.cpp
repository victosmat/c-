#include <bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int n, k, x;
        cin >> n >> k;
        int val[n + 5][k + 1];
        val[0][0] = 0;
        for (int i = 1; i < k; i++)
            val[0][i] = INT_MIN;
        for (int i = 1; i <= n; i++)
        {
            cin >> x;
            x %= k;
            for (int j = 0; j < k; j++)
                val[i][j] = max(val[i - 1][j], val[i - 1][(j + k - x) % k] + 1);
        }
        cout << val[n][0] << endl;
    }
}