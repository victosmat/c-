#include <bits/stdc++.h>
#define ll long long
using namespace std;

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        string str;
        cin >> str;
        int open = 0, close = 0;
        for (int i = 0; i < str.size(); ++i)
            if (str[i] == '(')
                open++;
            else
            {
                if (!open)
                    close++;
                else
                    open--;
            }
        int ans = (open / 2) + (close / 2) + (open % 2) + (close % 2);
        cout << ans << endl;
    }
}