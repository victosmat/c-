#include <bits/stdc++.h>
using namespace std;

int a[10], n, temp = 0;

bool check(int i, int n)
{
    if (n == 0)
        return true;
    else
    {
        if (i <= a[n - 1])
            return true;
        else
            return false;
    }
}

void Try(int k)
{
    for (int i = n; i >= 1; i--)
    {
        if (check(i, k))
        {
            a[k] = i;
            temp += i;
            if (temp == n)
            {
                cout << "(";
                for (int i = 0; i <= k; i++)
                {
                    cout << a[i];
                    if (i != k)
                        cout << " ";
                }
                cout << ") ";
            }
            else if (temp < n)
                Try(k + 1);
            temp -= i;
        }
    }
}

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        cin >> n;
        Try(0);
        cout << endl;
    }
}