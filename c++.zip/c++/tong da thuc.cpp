#include <bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    cin >> t;
    getchar();
    while (t--)
    {
        string s;
        int m[10005] = {};
        stringstream ss;
        int a, n;
        char c;
        getline(cin, s);
        ss << s;
        while (ss >> s)
        {
            if (s.length() == 1)
                continue;
            stringstream tmp;
            tmp << s;
            tmp >> a >> c >> c >> c >> n;
            m[n] += a;
        }

        getline(cin, s);
        ss.clear();
        ss << s;
        while (ss >> s)
        {
            if (s.length() == 1)
                continue;
            stringstream tmp;
            tmp << s;
            tmp >> a >> c >> c >> c >> n;
            m[n] += a;
        }

        int val;
        for (int i = 10000; i >= 0; i--)
            if (m[i] != 0)
            {
                cout << m[i] << "*x^" << i;
                val = i;
                break;
            }
        for (int i = val - 1; i >= 0; i--)
            if (m[i] != 0)
                cout << " + " << m[i] << "*x^" << i;
        cout << endl;
    }
}