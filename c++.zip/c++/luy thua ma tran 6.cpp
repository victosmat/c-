#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
#define m 1000000007;
ll a[10][10], b[10][10];
ll n, k;
const long long mod = 1000000007;

void Mul(ll x[][10], ll y[][10])
{
    ll tmp[10][10];
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            ll res = 0;
            for (int k = 0; k < n; k++)
                res += (x[i][k] * y[k][j]) % m;
            tmp[i][j] = res % m;
        }
    }
    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++)
            a[i][j] = tmp[i][j];
}
void Try(ll k)
{
    if (k <= 1)
        return;
    Try(k / 2);
    Mul(a, a);
    if (k % 2 == 1)
        Mul(a, b);
}

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        cin >> n >> k;
        for (int i = 0; i < n; i++)
            for (int j = 0; j < n; j++)
            {
                cin >> a[i][j];
                b[i][j] = a[i][j];
            }
        Try(k);
        long long sum = 0;
        for (int i = 0; i < n; i++)
            sum = (sum % mod + a[i][0] % mod) % mod;
        cout << sum << endl;
    }
}