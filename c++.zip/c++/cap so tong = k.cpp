#include <bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int n, k;
        cin >> n >> k;
        int a[n], b[n] = {0};
        for (int i = 0; i < n; i++)
            cin >> a[i];
        b[0] = 1;
        b[1] = 1;
        int count = 0;
        do
        {
            int sum = 0;
            for (int i = 0; i < n; i++)
                if (b[i])
                    sum += a[i];
            if (sum == k)
                count++;
        } while (prev_permutation(b, b + n));
        cout << count << endl;
    }
}