#include <bits/stdc++.h>
using namespace std;
#define INF 1000000

class dothi
{
    int n, a[100][100];

public:
    int s, d[100], val[100];
    void readdata();
    void init(int s);
    void bellman_ford(int s);
};

void dothi::readdata() 
{
    cin >> n >> s;
    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= n; j++)
        {
            cin >> a[i][j];
            if (a[i][j] == 0)
                a[i][j] = INF;
        }
}

void dothi::init(int s)
{
    for (int v = 1; v <= n; v++)
    {
        d[v] = a[s][v];
        val[v] = s;
    }
    d[s] = 0;
}

void dothi::bellman_ford(int s)
{
    init(s);
    for (int k = 1; k <= n - 2; k++)
        for (int v = 1; v <= n; v++)
            if (v != s)
                for (int u = 1; u <= n; u++)
                    if (a[u][v] != INF && d[u] != INF && d[v] > d[u] + a[u][v])
                    {
                        d[v] = d[u] + a[u][v];
                        val[v] = u;
                    }
    for (int t = 1; t <= n; t++)
    {
        if (d[t] == INF)
            cout << "\nK/c " << s << " -> " << t << " = INF; ";
        else
        {
            cout << "\nK/c " << s << " -> " << t << " = " << d[t] << ";";
            cout << "\t" << t << " <- ";
            int u = val[t];
            while (u != s)
            {
                cout << u << " <- ";
                u = val[u];
            }
            cout << s;
        }
    }
}

int main()
{
    dothi g;
    g.readdata();
    g.bellman_ford(g.s);
}