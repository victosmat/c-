#include <bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    cin >> t;
    while (t--)
    {

        long long n;
        cin >> n;
        long long res[n + 1] = {0};
        res[0] = 1;
        res[1] = 1;
        res[2] = 2;
        for (int i = 3; i <= n; i++)
            for (int j = 1; j <= 3; j++)
            {
                if (j > i)
                    break;
                res[i] += res[i - j];
            }
        cout << res[n] << endl;
    }
}