#include <iostream>
using namespace std;
int max(int x, int y)
{
    return (x > y) ? x : y;
}
int check(int n, int a[], int W)
{
    int K[n + 1][W + 1];
    for (int i = 0; i <= n; i++)
        for (int wt = 0; wt <= W; wt++)
        {
            if (i == 0 || wt == 0)
                K[i][wt] = 0;
            else if (a[i - 1] <= wt)
                K[i][wt] = max(a[i - 1] + K[i - 1][wt - a[i - 1]], K[i - 1][wt]);
            else
                K[i][wt] = K[i - 1][wt];
        }
    return K[n][W];
}
int main()
{
    int n, W;
    cin >> W >> n;
    int a[n];
    for (int i = 0; i < n; i++)
        cin >> a[i];
    cout << check(n, a, W) << endl;
}