#include <bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int n;
        cin >> n;
        int a[n];
        for (int i = 0; i < n; i++)
            cin >> a[i];
        for (int i = 0; i < n; i++)
        {
            int check = 0;
            for (int j = i + 1; j < n; j++)
            {
                if (a[j] > a[i])
                {
                    for (int k = a[j] + 1; k < n; k++)
                    {
                        if (a[k] < a[j])
                        {
                            check = 1;
                            cout << a[k] << endl;
                            break;
                        }
                    }
                }
            }
            if(!check)cout<<-1<<endl;
        }
        cout << endl;
    }
}