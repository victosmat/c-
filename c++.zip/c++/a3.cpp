#include <bits/stdc++.h>
using namespace std;
int main()
{
    int a, b;
    cin >> a >> b;
    queue<long long> q;
    queue<long long> an;
    q.push(4);
    q.push(7);
    while (b--)
    {
        long long s1 = q.front();
        q.pop();
        an.push(s1);
        long long s2 = s1;
        q.push(s1 * 10 + 4);
        q.push(s2 * 10 + 7);
    }
    long long s = 0;
    for (int i = a; i <= b; i++)
    {
        cout << i << " ";
    }
    cout << s << endl;
}