#include <bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        string s;
        cin >> s;
        int open = 0, close = 0;
        for (int i = 0; i < s.length(); i++)
        {
            if (s[i] == '(')
                open++;
            else
            {
                if (!open)
                    close++;
                else
                    open--;
            }
        }
        cout << (open / 2) + (close / 2) + (open % 2) + (open % 2) << endl;
    }
}