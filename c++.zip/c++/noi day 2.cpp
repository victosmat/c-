#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
#define m 1000000007

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        ll n;
        cin >> n;
        ll a[n + 5];
        for (ll i = 0; i < n; i++)
            cin >> a[i];
        priority_queue<ll, vector<ll>, greater<ll>> pq(a, a + n);
        ll sum = 0;
        while (pq.size() > 1)
        {
            ll val_1 = pq.top();
            pq.pop();
            ll val_2 = pq.top();
            pq.pop();
            sum += val_1 + val_2;
            sum %= m;
            pq.push((val_1 + val_2) % m);
        }
        cout << sum << endl;
    }
}