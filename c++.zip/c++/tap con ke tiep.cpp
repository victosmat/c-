#include <bits/stdc++.h>
using namespace std;
int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int n, m;
        cin >> m >> n;
        int a[n];
        for (int i = 0; i < n; i++)
            cin >> a[i];
        int k = n - 1;
        while (k >= 0 && a[k] == m - n + k + 1)
            k--;
        if (k >= 0)
        {
            a[k]++;
            for (int i = k + 1; i < n; i++)
            {
                a[i] = a[k] - k + i;
            }
            for (int i = 0; i < n; i++)
                cout << a[i] << " ";
        }
        else
            for (int i = 1; i < n; i++)
                cout << i << " ";
        cout << endl;
    }
}