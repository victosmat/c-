#include <bits/stdc++.h>
using namespace std;

int n, t, A[10];

void Try(int k)
{
    if (k == 0)
        return;
    int B[10];
    for (int i = 0; i < k - 1; i++)
    {
        B[i] = A[i];
        A[i] += A[i + 1];
    }
    B[k - 1] = A[k - 1];
    Try(k - 1);
    cout << "[" << B[0];
    for (int i = 1; i < k; i++)
    {
        cout << " " << B[i];
    }
    cout << "] ";
}

int main()
{
    cin >> t;
    while (t--)
    {
        cin >> n;
        for (int i = 0; i < n; i++)
            cin >> A[i];
        Try(n);
        cout << endl;
    }
}