#include <bits/stdc++.h>
using namespace std;

int v, e, a, b;
vector<int> ke[1003];
bool chuaxet[1003];

bool DFS(int u, int p)
{
    chuaxet[u] = false;
    for (int i = 0; i < ke[u].size(); i++)
    {
        if (chuaxet[ke[u][i]])
            DFS(ke[u][i], u);
        else if (ke[u][i] != p)
            return true;
    }
    return false;
}

bool check()
{
    for (int i = 1; i <= v; i++)
    {
        memset(chuaxet, true, sizeof(chuaxet));
        if (DFS(i, 0))
            return true;
    }
    return false;
}

void init()
{
    memset(chuaxet, true, sizeof(chuaxet));
    for (int i = 1; i <= v; i++)
        ke[i].clear();
}

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        cin >> v >> e;
        init();
        for (int i = 0; i < e; i++)
        {
            cin >> a >> b;
            ke[a].push_back(b);
        }
        if (check())
            cout << "YES" << endl;
        else
            cout << "NO" << endl;
    }
}