#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
#define M 1000000007
int t;
ll n, k;

ll luyThua(ll n, ll k)
{
    if (n == 0)
        return 1;
    ll x = luyThua(n / 2, k) % M;
    if (n % 2 == 0)
        return (x * x) % M;
    else
        return (((x * x) % M) * k) % M;
}
ll dao(ll n)
{
    ll m = 0;
    while (n)
    {
        m = m * 10 + n % 10;
        n /= 10;
    }
    return m;
}
int main()
{
    cin >> t;
    while (t--)
    {
        cin >> n;
        k = dao(n);
        cout << luyThua(k, n) << endl;
    }
}