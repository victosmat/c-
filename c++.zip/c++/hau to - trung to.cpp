#include <bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        string s;
        cin >> s;
        stack<string> a;
        for (int i = 0; i < s.length(); i++)
        {
            if (s[i] >= 'A' && s[i] <= 'Z')
                a.push(string(1, s[i]));
            else
            {
                string s1 = a.top();
                a.pop();
                string s2 = a.top();
                a.pop();
                string val = '(' + s2 + s[i] + s1 + ')';
                a.push(val);
            }
        }
        cout << a.top() << endl;
    }
}