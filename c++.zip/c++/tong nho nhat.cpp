#include <bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int k;
        cin >> k;
        int arr[k];
        for (int i = 0; i < k; i++)
            cin >> arr[i];
        sort(arr, arr + k);
        long long a = 0, b = 0;
        for (int i = 0; i < k; i++)
        {
            if (i % 2 == 0)
                a = a * 10 + arr[i];
            else
                b = b * 10 + arr[i];
        }
        cout << a + b<< endl;
    }
}