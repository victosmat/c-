#include <bits/stdc++.h>
using namespace std;

typedef long long ll;

int main()
{
    // int t;
    // cin >> t;
    ll f[31];
    f[0] = 1;
    for (int i = 1; i < 31; i++)
        f[i] = f[i - 1] * 2;
    int t;
    cin >> t;
    while (t--)
    {
        string s1, s2;
        cin >> s1 >> s2;
        reverse(s1.begin(), s1.end());
        reverse(s2.begin(), s2.end());
        long long sum1 = 0;
        for (int i = 0; i < s1.size(); i++)
            if (s1[i] == '1')
                sum1 += f[i];
        long long sum2 = 0;
        for (int i = 0; i < s2.size(); i++)
            if (s2[i] == '1')
                sum2 += f[i];
        cout << sum1 * sum2 << endl;
    }
}