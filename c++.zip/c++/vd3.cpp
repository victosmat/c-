#include <bits/stdc++.h>
using namespace std;

typedef struct PHANSO
{
    int TuSo;
    int MauSo;
} PS;

void Nhap(PS &x)
{
    cin >> x.TuSo >> x.MauSo;
}

int RutGon(PS &x)
{
    int ans = __gcd(x.TuSo, x.MauSo);
    x.TuSo /= ans;
    x.MauSo /= ans;
}

int main()
{
    PS PS;
    Nhap(PS);
    RutGon(PS);
    int a = PS.TuSo;
    int b = PS.MauSo;
    if (a % b == 0)
        cout << a / b;
    else
        cout << a << "/" << b;
}