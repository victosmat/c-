#include <bits/stdc++.h>
using namespace std;
int main()
{
    int n;
    cin >> n;
    int a[n];

    for (int i = 0; i < n; i++)
    
        cin >> a[i];
    int xet = 1;
    int h;
    for (int i = 0; i < n - 1; i++)
    {
        int test = INT_MAX;
        for (int j = i + 1; j < n; j++)
        {
            if (a[j] < test && a[j] < a[i])
            {
                test = a[j];
                h = j;
            }
        }
        swap(a[i], a[h]);
        cout << "Buoc " << xet++ << ": ";
        for (int k = 0; k < n; k++)
            cout << a[k] << " ";
        cout << endl;
        cout << endl;
    }
}