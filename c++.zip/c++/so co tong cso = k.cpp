#include <bits/stdc++.h>
using namespace std;

const long long mod = 1000000007;
long long val[101][50005];

int main()
{
    for (int i = 0; i < 101; i++)
        val[i][0] = 0;
    for (int i = 0; i < 50005; i++)
        val[0][i] = 0;
    for (int i = 1; i <= 9; i++)
        val[1][i] = 1;
    for (int i = 1; i <= 100; i++)
        for (int j = 0; j <= 9; j++)
            for (int h = j; h <= 50000; h++)
                val[i][h] = (val[i][h] % mod + val[i - 1][h - j] % mod) % mod;
    int t;
    cin >> t;
    while (t--)
    {
        int n, k;
        cin >> n >> k;
        cout << val[n][k] << endl;
    }
}