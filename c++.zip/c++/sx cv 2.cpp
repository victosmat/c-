#include <bits/stdc++.h>
using namespace std;

void sort_(int d[], int p[], int cnt)
{
    for (int i = 1; i < cnt; i++)
        for (int j = 0; j < i; j++)
            if (p[i] > p[j])
            {
                swap(p[i], p[j]);
                swap(d[i], d[j]);
            }
}

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int n;
        cin >> n;
        int a[1005];
        int b[1005];
        int cnt = 0;
        for (int i = 0; i < n; i++)
        {
            int j, d, p;
            cin >> j >> d >> p;
            a[cnt] = d;
            b[cnt] = p;
            cnt++;
        }
        sort_(a, b, cnt);
        int sum = 0, val = 0;
        vector<bool> check(n + 1, true);
        for (int i = 0; i < n; i++)
        {
            for (int j = min(n, a[i]); j >= 1; j--)
            {
                if (check[j])
                {
                    check[j] = false;
                    sum += b[i];
                    val++;
                    break;
                }
            }
        }
        cout << val << " " << sum << endl;
    }
}