#include <bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    cin >> t;
    getchar();
    while (t--)
    {
        string s;
        getline(cin, s);
        int max = 0, test = s.length();
        for (int i = 0; i < s.length(); i++)
        {
            if (s[i] == '0')
                continue;
            int count = 1;
            for (int j = i + 1; j < s.length(); j++)
            {
                if (s[i] == s[j])
                {
                    s[j] = '0';
                    count++;
                }
            }
            if (count > max)
                max = count;
        }
        if (test % 2 == 0)
        {
            if (test / 2 < max)
                cout << "-1" << endl;
            else
                cout << "1" << endl;
        }
        else
        {
            if (test / 2 + 1 < max)
                cout << "-1" << endl;
            else
                cout << "1" << endl;
        }
    }
}