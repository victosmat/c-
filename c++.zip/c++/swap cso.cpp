#include <iostream>
using namespace std;

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int n;
        cin >> n;
        string s;
        cin >> s;
        for (int i = 0; i < s.length(); i++)
        {
            char max = s[s.length() - 1];
            int val = s.length() - 1;
            for (int j = s.length() - 1; j > i && n > 0; j--)
            {
                if (s[j] > max)
                {
                    max = s[j];
                    val = j;
                }
            }
            if (max > s[i] && n > 0)
            {
                swap(s[i], s[val]);
                n--;
            }
        }
        cout << s << endl;
    }
}