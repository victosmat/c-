#include <bits/stdc++.h>
using namespace std;
const long long M = 1000000007;

int main()
{
    int t;
    cin >> t;
    while (t--)
    {

        long long n, k;
        cin >> n >> k;
        int res[n + 1] = {0};
        res[0] = 1;
        res[1] = 1;
        res[2] = 2;
        for (int i = 3; i <= n; i++)
            for (int j = 1; j <= k; j++)
            {
                if (j > i)
                    break;
                res[i] = (res[i] + res[i - j]) % M;
            }
        cout << res[n] << endl;
    }
}