#include <bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        string str1, str2;
        cin >> str1 >> str2;
        int n = str1.length(), m = str2.length();
        int a[n + 1][m + 1];
        for (int i = 0; i < n + 1; i++)
            for (int j = 0; j < m + 1; j++)
                a[i][j] = 0;
        for (int i = 0; i < n; i++)
            for (int j = 0; j < m; j++)
            {
                if (str1[i] == str2[j])
                    a[i + 1][j + 1] = a[i][j] + 1;
                else
                    a[i + 1][j + 1] = max(a[i][j + 1], a[i + 1][j]);
            }
        cout << a[n][m] << endl;
    }
}