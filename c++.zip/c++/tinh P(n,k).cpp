#include <bits/stdc++.h>
using namespace std;

#define m 1000000007

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int n, k;
        cin >> n >> k;
        if (k > n)
        {
            cout << 0 << endl;
            continue;
        }
        long long val = 1;
        for (int i = n - k + 1; i <= n; i++)
            val = (val * (i % m)) % m;
        cout << val << endl;
    }
}