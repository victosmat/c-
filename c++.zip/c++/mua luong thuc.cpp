#include <bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int s, n, m;
        cin >> n >> s >> m;
        if (((n * 6) < (m * 7) && s > 6) || m > n) //luong thuc mua < an trong 1 tuan
            cout << "-1" << endl;
        else
        {
            int count = (m * s) / n;
            if (((m * s) % n) != 0)
                count++;
            cout << count << endl;
        }
    }
}