#include <bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        string s;
        cin >> s;
        stack<long long> a;
        for (int i = 0; i < s.length(); i++)
        {
            if (s[i] == '+' || s[i] == '-' || s[i] == '*' || s[i] == '/')
            {
                long long val_1 = a.top();
                a.pop();
                long long val_2 = a.top();
                a.pop();
                long long val;
                if (s[i] == '+')
                    val = val_2 + val_1;
                else if (s[i] == '-')
                    val = val_2 - val_1;
                else if (s[i] == '*')
                    val = val_2 * val_1;
                else if (s[i] == '/')
                    val = val_2 / val_1;
                a.push(val);
            }
            else
            {
                long long val = 0;
                while (i < s.length() && s[i] >= '0' && s[i] <= '9')
                {
                    val = 10 * val + (int)(s[i] - '0');
                    i++;
                }
                a.push(val);
            }
        }
        cout << a.top() << endl;
    }
}