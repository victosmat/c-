#include <bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int n, s;
        long e;
        cin >> n >> e >> s;
        vector<vector<int>> A(n + 1, vector<int>(n + 1, 10000));
        int d[n + 1];
        bool chuaxet[n + 1];
        memset(chuaxet, true, sizeof chuaxet);
        for (long i = 1; i <= e; i++)
        {
            int x, y, z;
            cin >> x >> y >> z;
            if (A[x][y] > z)
                A[x][y] = A[y][x] = z;
        }
        for (int i = 1; i <= n; i++)
            d[i] = A[s][i];
        chuaxet[s] = false;
        d[s] = 0;
        for (int k = 1; k <= n; k++)
        {
            int min = 10000, u = 0;
            for (int i = 1; i <= n; i++)
                if (chuaxet[i] && min > d[i])
                {
                    min = d[i];
                    u = i;
                }
            chuaxet[u] = false;
            for (int i = 1; i <= n; i++)
                if (chuaxet[i] && d[i] > d[u] + A[u][i])
                    d[i] = d[u] + A[u][i];
        }
        for (int i = 1; i <= n; i++)
            cout << d[i] << " ";
        cout << endl;
    }
}