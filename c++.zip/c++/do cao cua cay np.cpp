#include <bits/stdc++.h>
using namespace std;

struct p
{
    int val = 0;
};

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int n;
        cin >> n;
        unordered_map<int, p> m;
        int high = 0;
        for (int i = 0; i < n - 1; i++)
        {
            int a, b;
            cin >> a >> b;
            m[b].val = m[a].val + 1;
            high = max(high, m[b].val);
        }
        cout << high << endl;
    }
}