#include <bits/stdc++.h>
using namespace std;

void sinh(int n, string s, int i)
{
    if (i == n)
    {
        int check = 1;
        for (int i = 0; i < s.length() / 2; i++)
        {
            if (s[i] != s[n - 1 - i])
            {
                check = 0;
                break;
            }
        }
        if (check == 1)
        {
            for (int i = 0; i < n; i++)
                cout << s[i] << " ";
            cout << endl;
        }
        return;
    }
    // sinh(n, s.append("0"), i + 1);
    // sinh(n, s.append("1"), i + 1);
    sinh(n, s + '0', i + 1);
    sinh(n, s + '1', i + 1);
}

int main()
{
    int n;
    cin >> n;
    string s;
    sinh(n, s, 0);
}