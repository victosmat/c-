#include <bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        string s;
        cin >> s;
        if (s.length() > 8)
        {
            cout << -1 << endl;
            continue;
        }
        string val(s.length() + 1, ' ');
        int count = 1;
        for (int i = 0; i <= s.length(); i++)
            if (i == s.length() || s[i] == 'I')
                for (int j = i - 1; j >= -1; j--)
                {
                    val[j + 1] = '0' + count++;
                    if (j >= 0 && s[j] == 'I')
                        break;
                }
        cout << val << endl;
    }
}