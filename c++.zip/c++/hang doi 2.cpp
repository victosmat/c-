#include <bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    cin >> t;
    queue<int> pq;
    while (t--)
    {
        string s;
        cin >> s;
        if (s == "PUSH")
        {
            int n;
            cin >> n;
            pq.push(n);
        }
        else if (s == "PRINTFRONT")
        {
            if (pq.empty())
                cout << "NONE" << endl;
            else
                cout << pq.front() << endl;
        }
        else
        {
            if (!pq.empty())
                pq.pop();
        }
    }
}