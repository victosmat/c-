#include <bits/stdc++.h>
using namespace std;
bool test(int a[], int n)
{
    for (int i = 0; i < n - 1; i++)
        if (a[i] > a[i + 1])
            return false;
    return true;
}
int main()
{
    int n;
    cin >> n;
    int a[n];
    for (int i = 0; i < n; i++)
        cin >> a[i];
    int xet = 1;
    for (int i = 0; i < n - 1; i++)
    {
        for (int j = 0; j < n - i - 1; j++)
        {
            if (a[j] > a[j + 1])
                swap(a[j], a[j + 1]);
        }
        cout << "Buoc " << xet++ << ": ";
        for (int k = 0; k < n; k++)
            cout << a[k] << " ";
        cout << endl;
        cout << endl;
        if (test(a, n) == true)
            break;
    }
}