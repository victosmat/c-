#include <bits/stdc++.h>
using namespace std;
int a[10], b[10], n, t;

void Try(int k)
{
    if (k == 0)
    {
        // cout << a[k];
        return;
    }
    int count = 0;
    for (int i = 0; i < k; i++)
        b[count++] = a[i] + a[i + 1];
    cout << "[";
    for (int i = 0; i < count; i++)
    {
        cout << b[i];
        if (i < count - 1)
            cout << " ";
        a[i] = b[i];
    }
    cout << "]" << endl
         << endl;
    Try(k - 1);
}

int main()
{
    cin >> t;
    while (t--)
    {
        cin >> n;
        for (int i = 0; i < n; i++)
            cin >> a[i];
        cout << "[";
        for (int i = 0; i < n; i++)
        {
            cout << a[i];
            if (i < n - 1)
                cout << " ";
        }
        cout << "]" << endl
             << endl;
        Try(n - 1);
    }
}