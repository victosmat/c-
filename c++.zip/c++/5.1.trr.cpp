//Xây dựng cây bao trùm DFS và BFS
#include <bits/stdc++.h>
using namespace std;
struct DS_canh
{
    int dau;
    int cuoi;
};
DS_canh T[100];
bool chuaxet[100];
int n, s, a[100][100], j;
void init()
{
    for (int i = 1; i <= n; i++)
    {
        chuaxet[i] = true;
        T[i].dau = 0;
        T[i].cuoi = 0;
    }
    j = 1;
}
void print_DS_canh()
{
    for (int i = 1; i < j; i++)
    {
        cout << T[i].dau << " " << T[i].cuoi;
        cout << endl;
    }
}
void DFS_Tree(int u)
{
    chuaxet[u] = false;
    for (int v = 1; v <= n; v++)
        if (a[u][v] == 1 && chuaxet[v])
        {
            T[j].dau = u;
            T[j].cuoi = v;
            ++j;
            DFS_Tree(v);
        }
}
void BFS_Tree(int u)
{
    queue<int> hangdoi;
    hangdoi.push(u);
    chuaxet[u] = false;
    while (!hangdoi.empty())
    {
        int v = hangdoi.front();
        hangdoi.pop();
        for (int t = 1; t <= n; t++)
            if (a[v][t] == 1 && chuaxet[t])
            {
                hangdoi.push(t);
                T[j].dau = v;
                T[j].cuoi = t;
                ++j;
                chuaxet[t] = false;
            }
    }
}
int main()
{
    //read data
    cin >> n >> s;
    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= n; j++)
            cin >> a[i][j];
    init();
    DFS_Tree(s);
    cout << "DFS tree " << endl;
    print_DS_canh();
    init();
    BFS_Tree(s);
    cout << "BFS tree " << endl;
    print_DS_canh();
}