//xây dựng cây bao trùm bé nhất theo kruskal
#include <bits/stdc++.h>
using namespace std;

struct edg
{
    int dau, cuoi, h;
};

class dothi
{
    int n, a[100][100], atree[100][100];

public:
    bool chuaxet[100];
    edg graph[100], tree[100];
    int ne, net; //số cạnh của dthi và cây
    void readdata();
    void bubblesort();
    void init();
    void dfstree(int u); //duyệt trên cây
    void kruskal();
};

void dothi::readdata()
{
    cin >> n;
    ne = 0;
    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= n; j++)
        {
            cin >> a[i][j];
            if (a[i][j] != 0 && i < j)
            {
                ne++;
                graph[ne].dau = i;
                graph[ne].cuoi = j;
            }
        }
}

void dothi::bubblesort()
{
    for (int i = 1; i <= ne; i++)
        for (int j = ne; j >= i + 1; j--)
            if (graph[j].h < graph[j - 1].h)
                swap(graph[j], graph[j - 1]);
}

void dothi::init()
{
    for (int i = 1; i <= n; i++)
        chuaxet[i] = true;
}

void dothi::dfstree(int u)
{
    chuaxet[u] = false;
    for (int i = 1; i <= n; i++)
        if (atree[u][i] == 1 && chuaxet[i] == true)
            dfstree(i);
}

void dothi::kruskal()
{
    int dH = 0, net = 0;
    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= n; j++)
            atree[i][j] = 0;
    bubblesort();
    for (int i = 1; i <= ne; i++)
    {
        int d = graph[i].dau;
        int c = graph[i].cuoi;
        init();
        dfstree(d);
        if (chuaxet[c] == true) //không tạo thành chu trình
        {
            net++;
            tree[net].dau = d;
            tree[net].cuoi = c;
            dH += graph[i].h;
            atree[d][c] = atree[c][d] = 1;
        }
    }
    cout << "dH = " << dH << endl;
    for (int i = 1; i <= net; i++)
        cout << tree[i].dau << " " << tree[i].cuoi << endl;
}

int main()
{
    dothi g;
    g.readdata();
    g.kruskal();
}
