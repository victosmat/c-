#include <bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        string s;
        cin >> s;
        string exp = "";
        exp += s[0];
        for (int i = 1; i < s.length(); i++)
        {
            if ((s[i - 1] == '0' && s[i] == '1') || (s[i - 1] == '1' && s[i] == '0'))
                exp += '1';
            else if ((s[i - 1] == '0' && s[i] == '0') || (s[i - 1] == '1' && s[i] == '1'))
                exp += '0';
        }
        cout << exp << endl;
    }
}