a = [101]

def solve():
    n = int(input())
    print(a[n])

def main():
    a[0] = 1
    for i in range(1,101):
        tmp=0
        for j in range(i):
            tmp+=a[j]*a[i-j-1]
        a.append(tmp)
    t = int(input())
    while(t > 0):
        t-=1
        solve()
main()