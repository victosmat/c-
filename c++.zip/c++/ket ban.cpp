#include <bits/stdc++.h>
using namespace std;

int v, e, a, b, val;
vector<int> ke[100003];
bool chuaxet[100003];

void BFS(int u)
{
    int count = 1;
    queue<int> q;
    q.push(u);
    chuaxet[u] = false;
    while (!q.empty())
    {
        int v = q.front();
        q.pop();
        for (int i = 0; i < ke[v].size(); i++)
        {
            int y = ke[v][i];
            if (chuaxet[y])
            {
                q.push(y);
                chuaxet[y] = false;
                count++;
            }
        }
    }
    val = max(val, count);
}

void init()
{
    memset(chuaxet, true, sizeof(chuaxet));
    for (int i = 1; i <= v; i++)
        ke[i].clear();
}

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        cin >> v >> e;
        init();
        val = 0;
        for (int i = 0; i < e; i++)
        {
            cin >> a >> b;
            ke[a].push_back(b);
            ke[b].push_back(a);
        }
        for (int i = 1; i <= v; i++)
            if (chuaxet[i])
                BFS(i);
        cout << val << endl;
    }
}