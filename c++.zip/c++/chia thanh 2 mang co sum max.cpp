#include <bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int n, k;
        cin >> n >> k;
        int a[n];
        for (int i = 0; i < n; i++)
            cin >> a[i];
        sort(a, a + n);
        long long sum1 = 0, sum2 = 0;
        for (int i = 0; i < k; i++)
            sum1 += a[i];
        for (int i = k; i < n; i++)
            sum2 += a[i];
        int test1 = sum2 - sum1;
        sum1 = 0, sum2 = 0;
        for (int i = 0; i < n - k; i++)
            sum1 += a[i];
        for (int i = n - k; i < n; i++)
            sum2 += a[i];
        int test2 = sum2 - sum1;
        if (test1 > test2)
            cout << test1 << endl;
        else
            cout << test2 << endl;
    }
}