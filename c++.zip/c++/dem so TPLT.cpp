#include <bits/stdc++.h>
using namespace std;

vector<int> a[1005];
bool chuaxet[1005];
long v, e, u;
int x, y;

void DFS(int u)
{
    chuaxet[u] = false;
    for (int i = 0; i < a[u].size(); i++)
        if (chuaxet[a[u][i]])
            DFS(a[u][i]);
}

void TPLT()
{
    int sotplt_ = 0;
    for (int i = 1; i <= v; i++)
    {
        if (chuaxet[i] == true)
        {
            sotplt_++;
            DFS(i);
        }
    }
    cout << sotplt_ << endl;
}

void init()
{
    for (int i = 1; i <= v; i++)
        chuaxet[i] = true;
    for (int i = 1; i <= v; i++)
        a[i].clear();
}

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        cin >> v >> e;
        init();
        for (long i = 0; i < e; i++)
        {
            cin >> x >> y;
            a[x].push_back(y);
            a[y].push_back(x);
        }
        TPLT();
    }
}