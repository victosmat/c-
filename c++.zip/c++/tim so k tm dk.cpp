#include <bits/stdc++.h>
using namespace std;

int dp[100002];
bool mark[6];

bool check(int a)
{
    memset(mark, false, sizeof(mark));
    while (a)
    {
        if (mark[a % 10])
            return false;
        mark[a % 10] = true;
        a /= 10;
    }
    return true;
}

main()
{
    queue<int> q;
    dp[0] = 1;
    for (int i = 1; i <= 5; i++)
        q.push(i);
    while (!q.empty())
    {
        int u = q.front();
        q.pop();
        if (check(u) == false)
            continue;
        if (u > 100000)
            break;
        dp[u] = 1;
        for (int i = 0; i <= 5; i++)
            q.push(u * 10 + i);
    }
    for (int i = 1; i <= 100000; i++)
        dp[i] += dp[i - 1];
    int t;
    cin >> t;
    while (t--)
    {
        int l, r;
        cin >> l >> r;
        if (l == 0)
            cout << dp[r] << endl;
        else
            cout << dp[r] - dp[l - 1] << endl;
    }
}