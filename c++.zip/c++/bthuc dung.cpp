#include <bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        string s;
        cin >> s;
        vector<int> a;
        for (int i = 0; i < s.length(); i++)
            if (s[i] == '(')
                a.push_back(i);
        int count = 0;
        int cnt = 0;
        int j = 0;
        for (int i = 0; i < s.length(); i++)
        {
            if (s[i] == ')')
            {
                cnt++;
                j++;
            }
            else
                cnt--;
            if (cnt < 0)
            {
                swap(s[i], s[a[j]]);
                cout << s << endl;
                count += a[j++] - i;
                cnt = 1;
            }
        }
        cout << count << endl;
    }
}