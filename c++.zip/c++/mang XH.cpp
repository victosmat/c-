#include <bits/stdc++.h>
using namespace std;

vector<int> a[100005];
bool chuaxet[100005];
long v, e, u;
int x, y;

void BFS(int u)
{
    queue<int> pq;
    pq.push(u);
    while (!pq.empty())
    {
        int v = pq.front();
        pq.pop();
        chuaxet[v] = true;
        for (int i = 0; i < a[v].size(); i++)
            if (!chuaxet[a[v][i]])
                pq.push(a[v][i]);
    }
}

void init()
{
    memset(chuaxet, false, sizeof chuaxet);
    for (int i = 1; i <= v; i++)
        a[i].clear();
}

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        cin >> v >> e;
        init();
        for (long i = 0; i < e; i++)
        {
            cin >> x >> y;
            a[x].push_back(y);
            a[y].push_back(x);
        }
        BFS(1);
        bool check = true;
        for (int i = 1; i <= v; i++)
            if (!chuaxet[i])
                check = false;
        (check) ? cout << "YES" << endl : cout << "NO" << endl;
    }
}