#include <iostream>
#include <vector>
#include <unordered_map>
using namespace std;

struct p
{
    int val = 0;
    bool isNode = false;
};

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int n, a, b;
        string s;
        cin >> n;
        unordered_map<int, p> m;
        for (int i = 0; i < n; i++)
        {
            cin >> a >> b >> s;
            m[b].val = m[a].val + 1;
            m[a].isNode = true;
        }
        vector<int> ans;
        for (auto it : m)
            if (!it.second.isNode)
                ans.push_back(it.second.val);
        bool check = true;
        for (int i = 0; i < ans.size() - 1; i++)
            if (ans[i] != ans[i + 1])
                check = false;
        (check) ? cout << 1 << endl : cout << 0 << endl;
    }
}