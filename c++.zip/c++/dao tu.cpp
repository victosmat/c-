#include <bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    cin >> t;
    getchar();
    while (t--)
    {
        string S, token, a[100];
        getline(cin, S);
        stringstream ss(S);
        int count = 0;
        while (ss >> token)
            a[count++] = token;
        for (int i = count - 1; i >= 0; i--)
            cout << a[i] << " ";
        cout << endl;
    }
}