#include <bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int n;
        cin >> n;
        int a[n];
        int b[100000] = {};
        for (int i = 0; i < n; i++)
        {
            cin >> a[i];
            b[a[i]]++;
        }
        for (int i = 0; i < n; i++)
        {
            int val = -1;
            for (int j = i + 1; j < n; j++)
            {
                if (b[a[j]] > b[a[i]])
                {
                    val = a[j];
                    break;
                }
            }
            cout << val << " ";
        }
        cout << endl;
    }
}