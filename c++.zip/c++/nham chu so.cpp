#include <bits/stdc++.h>
using namespace std;

int main()
{
    string s1, s2;
    cin >> s1 >> s2;
    int a1 = 0, a2 = 0;
    for (int i = 0; i < s1.length(); i++)
        if (s1[i] == '6')
            s1[i] = '5';
    for (int i = 0; i < s2.length(); i++)
        if (s2[i] == '6')
            s2[i] = '5';
    for (int i = 0; i < s1.length(); i++)
        a1 = a1 * 10 + s1[i] - '0';
    for (int i = 0; i < s2.length(); i++)
        a2 = a2 * 10 + s2[i] - '0';
    cout << a1 + a2 << " ";
    int b1 = 0, b2 = 0;
    for (int i = 0; i < s1.length(); i++)
        if (s1[i] == '5')
            s1[i] = '6';
    for (int i = 0; i < s2.length(); i++)
        if (s2[i] == '5')
            s2[i] = '6';
    for (int i = 0; i < s1.length(); i++)
        b1 = b1 * 10 + s1[i] - '0';
    for (int i = 0; i < s2.length(); i++)
        b2 = b2 * 10 + s2[i] - '0';
    cout << b1 + b2 << endl;
}