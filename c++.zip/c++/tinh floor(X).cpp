#include <bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        long long n, k;
        cin >> n >> k;
        long long test = -1;
        vector<long long> a(n);
        for (int i = 0; i < n; i++)
        {
            cin >> a[i];
            if (a[i] <= k)
                test = i;
        }
        if (test == -1)
            cout << "-1" << endl;
        else
            cout << test + 1 << endl;
    }
}