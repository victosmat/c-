#include <bits/stdc++.h>
using namespace std;

int main()
{
    int n;
    cin >> n;
    int a[n], val[n] = {};
    for (int i = 0; i < n; i++)
        cin >> a[i];
    int result = INT_MIN;
    for (int i = 0; i < n; i++)
    {
        val[a[i]] = val[a[i] - 1] + 1;
        result = max(result, val[a[i]]);
    }
    cout << n - result << endl;
}