#include <bits/stdc++.h>
using namespace std;

int a[1001], val[1001], cnt[1001];
int dem = 0;

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int n;
        cin >> n;
        for (int i = 0; i < n; i++)
            cin >> a[i];
        int check = 0;
        a[n] = 0;
        sort(a, a + n);
        for (int i = 0; i < n; i++)
        {
            check++;
            if (a[i] != a[i + 1])
            {
                val[dem] = a[i];
                cnt[dem] = check;
                check = 0, dem++;
            }
        }
        for (int i = 0; i < dem; i++)
            for (int j = i + 1; j < dem; j++)
            {
                if (cnt[i] < cnt[j])
                {
                    swap(cnt[i], cnt[j]);
                    swap(val[i], val[j]);
                }
                else if (val[i] > val[j] && cnt[i] == cnt[j])
                    swap(val[i], val[j]);
            }
        for (int i = 0; i < dem; i++)
            for (int j = 0; j < cnt[i]; j++)
                cout << val[i] << " ";
        dem = 0;
        cout << endl;
    }
}