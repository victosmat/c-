#include <bits/stdc++.h>
using namespace std;
int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int n, m;
        cin >> n >> m;
        int a[n];
        for (int i = 0; i < n; i++)
            cin >> a[i];
        for (int i = 0; i < n - 1; i++)
            for (int j = 0; j < n - i - 1; j++)
                if (abs(m - a[j]) > abs(m - a[j + 1]))
                    swap(a[j + 1], a[j]);
        for (int i = 0; i < n; i++)
            cout << a[i] << " ";
        cout << endl;
    }
}