#include <bits/stdc++.h>
using namespace std;

vector<int> ke[1005];
int v, e, x, y;
int val[1005];
bool check;

bool BFS(int u)
{
    val[u] = 1;
    queue<int> pq;
    pq.push(u);
    while (!pq.empty())
    {
        int v = pq.front();
        pq.pop();
        for (int i = 0; i < ke[v].size(); i++)
            if (val[v] == val[ke[v][i]])
                return false;
            else if (val[ke[v][i]] == -1)
            {
                val[ke[v][i]] = 1 - val[v];
                pq.push(ke[v][i]);
            }
    }
    return true;
}

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        cin >> v >> e;
        for (int i = 1; i <= v; i++)
            ke[i].clear();
        for (int i = 0; i < e; i++)
        {
            cin >> x >> y;
            ke[x].push_back(y);
            ke[y].push_back(x);
        }
        bool check = true;
        for (int i = 1; i <= v; i++)
            val[i] = -1;
        for (int i = 1; i <= v; i++)
            if (val[i] == -1)
                if (!BFS(i))
                    check = false;
        (check) ? cout << "YES" << endl : cout << "NO" << endl;
    }
}