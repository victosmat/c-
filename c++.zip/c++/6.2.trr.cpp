//Programming practice & homework 6.2: Shortest path using Dijkstra algorithm
#include <iostream>
#define MAX 100
#define INF 1000000
using namespace std;
class dothi
{
    int n, a[MAX][MAX];

public:
    bool chuaxet[MAX];
    int s, d[MAX], val[MAX];
    void readdata();
    void init(int s);
    void dijkstra(int s);
};
void dothi::readdata()
{
    cin >> n >> s;
    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= n; j++)
        {
            cin >> a[i][j];
            if (a[i][j] == 0)
                a[i][j] = INF;
        }
}
void dothi::init(int s)
{
    for (int v = 1; v <= n; v++)
    {
        d[v] = a[s][v];
        val[v] = s;
        chuaxet[v] = true;
    }
    d[s] = 0;
    chuaxet[s] = false;
}
void dothi::dijkstra(int s)
{
    init(s);
    for (int i = 1; i <= n; i++)
    {
        if (chuaxet[i] == true)
        { //Ton tai dinh tam thoi (tap T != rong), thuc hien buoc lap
            //Tim u va du=min{dz, z thuoc tap nhan tam thoi}
            int u = 0, du = INF;
            for (int z = 1; z <= n; z++)
                if ((chuaxet[z] == true) && (d[z] < du))
                {
                    u = z;
                    du = d[z];
                }
            if (u != 0)
            { //Tim duoc u de co dinh
                //co dinh u
                chuaxet[u] = false;
                //Cap nhat cac nhan tam thoi
                for (int v = 1; v <= n; v++)
                    if ((chuaxet[v] == true) && (d[v] > du + a[u][v]))
                    {
                        d[v] = du + a[u][v];
                        val[v] = u;
                    }
            }
            else
            { //khong tim duoc u -> khong co duong di tu s -> i
                chuaxet[i] = false;
            }
            //Moi lan co dinh duoc 1 dinh, quay lai xet toan bo tap dinh
            i = 0;
        }
    }
    //in kq
    for (int t = 1; t <= n; t++)
        if (d[t] == INF)
            cout << "\nK/c " << s << " -> " << t << " = INF;";
        else
        {
            cout << "\nK/c " << s << " -> " << t << " = " << d[t] << ";";
            cout << "\t" << t << " <- ";
            int u = val[t];
            while (u != s)
            {
                cout << u << " <- ";
                u = val[u];
            }
            cout << s;
        }
}
int main()
{
    dothi g;
    g.readdata();
    g.dijkstra(g.s);
}