#include <bits/stdc++.h>
using namespace std;

int n, k, check;
int a[105], sum;
bool chuaxet[105];

void Try(int i, int check, int sum)
{
    for (int j = i; j < n; j++)
    {
        if (check + a[j] <= sum && chuaxet[a[j]])
        {
            chuaxet[a[j]] = false;
            check += a[j];
            Try(i + 1, check, sum);
            check -= a[j];
            chuaxet[a[j]] = true;
        }
    }
}

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        cin >> n >> k;
        sum = 0, check = 0;
        memset(chuaxet, true, sizeof chuaxet);
        for (int i = 0; i < n; i++)
        {
            cin >> a[i];
            sum += a[i];
        }
        if (sum % k != 0)
        {
            cout << 0 << endl;
            continue;
        }
        sum /= k;
        Try(0, check, sum);
    }
}