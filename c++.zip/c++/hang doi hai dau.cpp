#include <bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    cin >> t;
    deque<int> pq;
    while (t--)
    {
        string s;
        cin >> s;
        if (s == "PUSHFRONT")
        {
            int n;
            cin >> n;
            pq.push_front(n);
        }
        else if (s == "PRINTFRONT")
        {
            if (pq.empty())
                cout << "NONE" << endl;
            else
                cout << pq.front() << endl;
        }
        else if (s == "POPFRONT")
        {
            if (!pq.empty())
                pq.pop_front();
        }
        else if (s == "PUSHBACK")
        {
            int n;
            cin >> n;
            pq.push_back(n);
        }
        else if (s == "PRINTBACK")
        {
            if (pq.empty())
                cout << "NONE" << endl;
            else
                cout << pq.back() << endl;
        }
        else
        {
            if (!pq.empty())
                pq.pop_back();
        }
    }
}