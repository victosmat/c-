#include <bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        string s;
        cin >> s;
        stack<string> a;
        for (int i = 0; i < s.length(); i++)
        {
            if (s[i] == '+' || s[i] == '-' || s[i] == '*' || s[i] == '/')
            {
                string s1 = a.top();
                a.pop();
                string s2 = a.top();
                a.pop();
                string val;
                val = s2 + s[i] + s1;
                a.push(val);
            }
            else
                a.push(string(1, s[i]));
        }
        cout << a.top() << endl;
    }
}