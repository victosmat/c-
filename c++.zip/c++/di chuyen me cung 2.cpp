#include <bits/stdc++.h>
using namespace std;

int a[10][10], n, test;
bool check[10][10];
vector<string> res;

void Try(int i, int j, string s)
{
    if (a[0][0] == 0 || a[n - 1][n - 1] == 0)
        return;
    if (i == n - 1 && j == n - 1 && a[i][j])
    {
        test++;
        res.push_back(s);
        return;
    }
    if (a[i][j + 1] && j < n - 1 && !check[i][j])
    {
        check[i][j] = true;
        Try(i, j + 1, s + "R");
        check[i][j] = false;
    }
    if (a[i][j - 1] && j >= 0 && !check[i][j])
    {
        check[i][j] = true;
        Try(i, j - 1, s + "L");
        check[i][j] = false;
    }
    if (a[i + 1][j] && i < n - 1 && !check[i][j])
    {
        check[i][j] = true;
        Try(i + 1, j, s + "D");
        check[i][j] = false;
    }
    if (a[i - 1][j] && i >= 0 && !check[i][j])
    {
        check[i][j] = true;
        Try(i - 1, j, s + "U");
        check[i][j] = false;
    }
}
int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        cin >> n;
        for (int i = 0; i < n; ++i)
            for (int j = 0; j < n; ++j)
            {
                cin >> a[i][j];
                check[i][j] = false;
            }
        res.clear();
        test = 0;
        Try(0, 0, "");
        if (!test)
            cout << -1 << endl;
        else
        {
            sort(res.begin(), res.end());
            for (int i = 0; i < res.size(); ++i)
                cout << res[i] << " ";
            cout << endl;
        }
    }
}