#include <bits/stdc++.h>
using namespace std;

const long long mod = 1000000007;

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int n;
        cin >> n;
        long long a[105][105];
        for (int i = 0; i <= n; i++)
            for (int j = 1; j <= 10; j++)
                if (i == 0 || j == 1)
                    a[i][j] = 1;
                else
                    a[i][j] = (a[i - 1][j] % mod + a[i][j - 1] % mod) % mod;
        cout << a[n][10] << endl;
    }
}