#include <bits/stdc++.h>
using namespace std;

void showstack(stack<int> s)
{
    int i = 0, a[200];
    while (!s.empty())
    {
        a[i++] = s.top();
        s.pop();
    }
    for (int j = i - 1; j >= 0; j--)
        cout << a[j] << " ";
    cout << "\n";
}

int main()
{
    stack<int> s;
    int i = 0;
    while (i++ < 200)
    {
        string str;
        cin >> str;
        if (str == "push")
        {
            int n;
            cin >> n;
            s.push(n);
        }
        else if (str == "pop")
            s.pop();
        else if (str == "show")
        {
            if (s.empty())
                cout << "empty\n";
            else
                showstack(s);
        }
    }
}