#include <bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int n;
        cin >> n;
        int a;
        priority_queue<int, vector<int>, greater<int>> test;
        for (int i = 0; i < n; i++)
        {
            cin >> a;
            test.push(a);
        }
        long long sum = 0;
        while (test.size() > 1)
        {
            int sum1 = test.top();
            test.pop();
            int sum2 = test.top();
            test.pop();
            sum += sum1 + sum2;
            test.push(sum1 + sum2);
        }
        cout << sum << endl;
    }
}