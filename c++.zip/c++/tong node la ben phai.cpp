#include <bits/stdc++.h>
using namespace std;

struct p
{
    int left = -1;
    int right = -1;
};

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int n;
        cin >> n;
        unordered_map<int, p> m;
        int first = -1;
        for (int i = 0; i < n; i++)
        {
            int a, b;
            char c;
            cin >> a >> b >> c;
            if (first == -1)
                first = a;
            if (c == 'L')
                m[a].left = b;
            if (c == 'R')
                m[a].right = b;
        }
        queue<int> pq;
        pq.push(first);
        int sum = 0;
        while (!pq.empty())
        {
            first = pq.front();
            pq.pop();
            if (m[first].left != -1)
                pq.push(m[first].left);
            if (m[first].right != -1)
            {
                int val = m[first].right;
                if (m[val].left == -1)
                    sum += val;
                pq.push(val);
            }
        }
        cout << sum << endl;
    }
}