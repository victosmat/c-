#include <bits/stdc++.h>
using namespace std;

int min(int a, int b, int c)
{
    int k = min(a, b);
    return min(k, c);
}

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int n, m;
        cin >> n >> m;
        int val[n][m];
        for (int i = 0; i < n; i++)
            for (int j = 0; j < m; j++)
                cin >> val[i][j];
        for (int i = 1; i < m; i++)
            val[0][i] += val[0][i - 1];
        for (int i = 1; i < n; i++)
            val[i][0] += val[i - 1][0];
        for (int i = 1; i < n; i++)
            for (int j = 1; j < m; j++)
                val[i][j] += min(val[i - 1][j], val[i - 1][j - 1], val[i][j - 1]);
        cout << val[n - 1][m - 1] << endl;
    }
}