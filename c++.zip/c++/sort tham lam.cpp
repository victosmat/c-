#include <bits/stdc++.h>
using namespace std;

bool volve(int arr[], int n)
{
    int test[n];
    copy(arr, arr + n, test);
    sort(test, test + n);
    for (int i = 0; i < n; i++)
        if ((arr[i] != test[i]) && (arr[n - 1 - i] != test[i]))
            return false;
    return true;
}

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int k;
        cin >> k;
        int arr[k];
        for (int i = 0; i < k; i++)
            cin >> arr[i];
        int n = sizeof(arr) / sizeof(arr[0]);
        if (volve(arr, n))
            cout << "Yes";
        else
            cout << "No";
        cout << endl;
    }
}