#include <bits/stdc++.h>
using namespace std;

bool check;
vector<int> ke[20];
bool val[20];
int v, e, a, b;

void init()
{
    for (int i = 1; i <= v; i++)
        ke[i].clear();
    memset(val, false, sizeof(val));
}

bool hamilton(int u, int count)
{
    if (count == v)
        return true;
    val[u] = true;
    for (int i = 0; i < ke[u].size(); i++)
        if (!val[ke[u][i]] && hamilton(ke[u][i], count + 1))
            return true;
    val[u] = false;
    return false;
}

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        cin >> v >> e;
        init();
        check = false;
        for (int i = 0; i < e; i++)
        {
            cin >> a >> b;
            ke[a].push_back(b);
            ke[b].push_back(a);
        }
        for (int i = 1; i <= v; i++)
            if (hamilton(i, 1))
            {
                check = true;
                break;
            }
        (check) ? cout << 1 << endl : cout << 0 << endl;
    }
}