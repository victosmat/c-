#include <bits/stdc++.h>
using namespace std;
int main()
{
    int t;
    cin >> t;
    getchar();
    while (t--)
    {
        string s;
        getline(cin, s);
        int i = s.length() - 1;
        while (i >= 0 && s[i] == '1')
        {
            s[i] = '0';
            i--;
        }
        if (i == -1)
            for (int k = 0; k < s.length(); k++)
                s[k] = '0';
        else
            s[i] = '1';
        for (int k = 0; k < s.length(); k++)
            cout << s[k];
        cout << endl;
    }
}