#include <bits/stdc++.h>
using namespace std;

int sum, a[100], b[100], n, test, check = 0, dem = 0;

void Try(int k)
{
    for (int i = 0; i <= 1; i++)
    {
        a[k] = i;
        if (k == n - 1)
        {
            int sum = 0;
            for (int j = 0; j < n; j++)
                if (a[j] == 1)
                    sum += b[j];
            if (sum == test)
            {
                dem++;
                check = 1;
                for (int j = 0; j < n; j++)
                    if (a[j] == 1)
                        cout << b[j] << " ";
                cout << endl;
            }
        }
        else
            Try(k + 1);
    }
}
int main()
{
    check = 0;
    cin >> n >> test;
    for (int i = 0; i < n; i++)
        cin >> b[i];
    sort(b, b + n);
    Try(0);
    if (check == 0)
        cout << -1;
    cout << dem << endl;
}