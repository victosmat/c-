#include <bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int n;
        cin >> n;
        int a[n + 5];
        bool check[n + 5];
        for (int i = 0; i < n; i++)
            cin >> a[i];
        sort(a, a + n);
        int i = 0, j = n / 2, count = 0;
        while (i < n / 2 && j < n)
        {
            if (a[i] * 2 <= a[j])
                count++, i++, j++;
            else
                j++;
        }
        cout << n - count << endl;
    }
}