#include <bits/stdc++.h>
using namespace std;

int v, e, x, y;
int check = 0;
vector<int> a[1005];
int chuaxet[1005];

void init()
{
    for (int i = 1; i <= v; i++)
        chuaxet[i] = true;
    for (int i = 0; i < v; i++)
        a[i].clear();
}

void euler(int u)
{
    stack<int> pq;
    stack<int> ce;
    pq.push(u);
    while (!pq.empty())
    {
        int tmp = pq.top();
        bool rong = true;
        for (int i = 0; i < a[tmp].size(); i++)
        {
            if (a[tmp][i] > 0)
            {
                pq.push(a[tmp][i]);
                a[tmp][i] = 0;
                rong = false;
                break;
            }
        }
        if (rong)
        {
            pq.pop();
            ce.push(tmp);
        }
    }
    int val;
    while (!ce.empty())
    {
        val = ce.top();
        ce.pop();
    }
    if (val == u)
        check = 1;
}

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        cin >> v >> e;
        init();
        for (int i = 0; i < e; i++)
        {
            cin >> x >> y;
            a[x].push_back(y);
        }
        euler(1);
        if (check)
            cout << 1 << endl;
        else
            cout << 0 << endl;
        check = 0;
    }
}