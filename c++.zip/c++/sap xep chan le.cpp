#include <bits/stdc++.h>
using namespace std;

int main()
{
    int n;
    cin >> n;
    int a[n];
    vector<int> tang, giam;
    for (int i = 0; i < n; i++)
    {
        cin >> a[i];
        if (i % 2 == 0)
            tang.push_back(a[i]);
        else
            giam.push_back(a[i]);
    }
    int t = 0, g = 0;
    sort(tang.begin(), tang.end());
    sort(giam.begin(), giam.end(), greater<int>());
    for (int i = 0; i < n; i++)
        if (i % 2 == 0)
            cout << tang[t++] << " ";
        else
            cout << giam[g++] << " ";
}