#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main()
{
    int n, dem = 0;
    cin >> n;
    string s;
    cin >> s;
    int X = 0, T = 0;
    for (int i = 0; i < s.length(); i++)
    {
        if (s[i] == 'X')
            X++;
        else if (s[i] == 'T')
            T++;
    }
    for (int i = 0; i < X; i++)
    {
        if (s[i] == 'D')
        {
            for (int j = n - 1; j >= X; j--)
            {
                if (s[j] == 'X')
                {
                    dem++;
                    swap(s[i], s[j]);
                    break;
                }
            }
        }
        else if (s[i] == 'T')
        {
            for (int j = X; j < n; j++)
            {
                if (s[j] == 'X')
                {
                    dem++;
                    swap(s[i], s[j]);
                    break;
                }
            }
        }
    }
    for (int i = X; i < X + T; i++)
        if (s[i] == 'D')
            dem++;
    cout << dem;
}