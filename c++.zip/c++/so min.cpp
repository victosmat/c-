#include <bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int s, d;
        cin >> s >> d;
        if (s > 9 * d)
        {
            cout << -1 << endl;
            continue;
        }
        int val[d];
        s -= 1;
        for (int i = d - 1; i >= 0; i--)
        {
            if (s > 9)
            {
                val[i] = 9;
                s -= 9;
            }
            else
            {
                val[i] = s;
                s = 0;
            }
        }
        val[0] += 1;
        for (int i = 0; i < d; i++)
            cout << val[i];
        cout << endl;
    }
}