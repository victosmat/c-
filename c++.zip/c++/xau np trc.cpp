#include <bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        string s;
        cin >> s;
        int k = s.length() - 1;
        while (s[k] == '0')
            k--;
        if (k == -1)
        {
            for (int i = 0; i < s.length(); i++)
                cout << 1;
            cout << endl;
            continue;
        }
        s[k] = '0';
        for (int i = 0; i < s.length(); i++)
        {
            if (i > k)
                s[i] = '1';
            cout << s[i];
        }
        cout << endl;
    }
}