#include <bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        string s;
        cin >> s;
        long long n = s.size();
        long long a[n], res;
        res = a[0] = s[0] - '0';
        for (long long i = 1; i < n; i++)
        {
            a[i] = (i + 1) * (s[i] - '0') + 10 * a[i - 1];
            res += a[i];
        }
        cout << res << endl;
    }
}