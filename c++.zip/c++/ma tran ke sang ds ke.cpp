#include <bits/stdc++.h>
using namespace std;

int main()
{
    int n, x;
    cin >> n;
    for (int i = 1; i <= n; i++)
    {
        vector<int> a;
        for (int j = 1; j <= n; j++)
        {
            cin >> x;
            if (x == 1)
                a.push_back(j);
        }
        for (int i = 0; i < a.size(); i++)
            cout << a[i] << " ";
        cout << endl;
    }
}