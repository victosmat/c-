#include <bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int n;
        cin >> n;
        int a[n];
        for (int i = 0; i < n; i++)
            cin >> a[i];
        int val_1 = a[0];
        int val_2 = 0;
        int c;
        for (int i = 1; i < n; i++)
        {
            c = max(val_1, val_2);
            val_1 = val_2 + a[i];
            val_2 = c;
        }
        cout << max(val_1, val_2) << endl;
    }
}