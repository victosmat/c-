#include <bits/stdc++.h>
using namespace std;

vector<int> a[1005];
bool chuaxet[1005];
long v, e, s, t;
int x, y, check;

void DFS(int u)
{
    chuaxet[u] = false;
    if (u == t)
    {
        check = 1;
        cout << "YES" << endl;
        return;
    }
    for (int i = 0; i < a[u].size(); i++)
        if (chuaxet[a[u][i]])
            DFS(a[u][i]);
}

void init()
{
    for (int i = 1; i <= v; i++)
        chuaxet[i] = true;
    for (int i = 1; i <= v; i++)
        a[i].clear();
}

int main()
{
    int test;
    cin >> test;
    while (test--)
    {
        cin >> v >> e;
        init();
        for (long i = 0; i < e; i++)
        {
            cin >> x >> y;
            a[x].push_back(y);
            a[y].push_back(x);
        }
        int k;
        cin >> k;
        while (k--)
        {
            check = 0;
            for (int i = 1; i <= v; i++)
                chuaxet[i] = true;
            cin >> s >> t;
            DFS(s);
            if (!check)
                cout << "NO" << endl;
        }
    }
}