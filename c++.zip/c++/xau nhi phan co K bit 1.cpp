#include <bits/stdc++.h>
using namespace std;
int a[100], n, k, t;
void test(int a[])
{
    int dem = 0;
    for (int i = 0; i < n; i++)
    {
        if (a[i] == 1)
            dem++;
    }
    if (dem == k)
    {
        for (int i = 0; i < n; i++)
            cout << a[i];
        cout << endl;
    }
}
void volve()
{
    memset(a, 0, sizeof(a));
    test(a);
    bool check = 0;
    while (1)
    {
        for (int i = n - 1; i >= -1; i--)
        {
            if (i >= 0 && a[i] == 0)
            {
                a[i] = 1;
                for (int j = i + 1; j < n; j++)
                    a[j] = 0;
                break;
            }
            else if (i == -1)
                check = 1;
        }
        test(a);
        if (check)
            break;
    }
}

int main()
{
    cin >> t;
    while (t--)
    {
        cin >> n >> k;
        volve();
    }
}