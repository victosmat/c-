#include <bits/stdc++.h>
using namespace std;
int main()
{
    int n;
    cin >> n;
    int a[n];
    for (int i = 0; i < n; i++)
        cin >> a[i];
    int xet = 0;
    cout << "Buoc " << xet++ << ": " << a[0] << " ";
    cout << endl << endl;
    int key, j;
    for (int i = 1; i < n; i++)
    {
        key = a[i];
        j = i - 1;
        while (j >= 0 && a[j] > key)
        {
            a[j + 1] = a[j];
            j = j - 1;
        }
        a[j + 1] = key;
        cout << "Buoc " << xet++ << ": ";
        for (int k = 0; k <= i; k++)
            cout << a[k] << " ";
        cout << endl;
        cout << endl;
    }
}