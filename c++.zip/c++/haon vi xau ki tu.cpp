#include <bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    cin >> t;
    getchar();
    while (t--)
    {
        string s;
        getline(cin, s);
        cout << s << " ";
        while (1)
        {
            int i = s.length() - 2;
            while (i >= 0 && s[i] > s[i + 1])
                i--;
            if (i == -1)
                break;
            int k = s.length() - 1;
            while (s[k] < s[i])
                k--;
            swap(s[k], s[i]);
            int l = i + 1, r = s.length() - 1;
            while (l < r)
            {
                swap(s[l], s[r]);
                l++, r--;
            }
            cout << s << " ";
        }
        cout << endl;
    }
}