#include <bits/stdc++.h>
using namespace std;

vector<string> arr;

void duyet()
{
    queue<string> pq;
    pq.push("4");
    pq.push("7");
    for (int i = 0; i < 10000; i++)
    {
        string s1 = pq.front();
        pq.pop();
        arr.push_back(s1);
        string s2 = s1;
        pq.push(s1 + '4');
        pq.push(s2 + '7');
    }
}

int main()
{
    duyet();
    int a, b;
    cin >> a >> b;
    int sum = 0;
    for (int i = a; i <= b; i++)
        for (int j = 0; j < arr.size(); j++)
        {
            if (stoi(arr[j]) >= i)
            {
                cout << stoi(arr[j]) << " ";
                sum += stoi(arr[j]);
                break;
            }
        }
    cout << sum << endl;
}