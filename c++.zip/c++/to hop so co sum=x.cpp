#include <bits/stdc++.h>
using namespace std;

vector<int> v;
vector<vector<int>> arr;
int a[21];
int n, s;
bool ok;
int cnt;

void out(int i, int sum)
{
    if (sum > s)
        return;
    if (sum == s)
    {
        arr.push_back(v);
        cnt++;
        ok = true;
        return;
    }
    for (int j = i; j < n; ++j)
    {
        if (sum + a[j] <= s)
        {
            v.push_back(a[j]);
            out(j, sum + a[j]);
            v.pop_back();
        }
    }
}

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        arr.clear();
        ok = false;
        cnt = 0;
        cin >> n >> s;
        for (int i = 0; i < n; ++i)
            cin >> a[i];
        out(0, 0);
        if (!ok)
            cout << -1 << endl;
        else
        {
            cout << cnt << " ";
            for (int i = 0; i < arr.size(); i++)
            {
                cout << "{";
                for (int j = 0; j < arr[i].size(); j++)
                {
                    cout << arr[i][j];
                    if (j != arr[i].size() - 1)
                        cout << " ";
                }
                cout << "} ";
            }
            cout << endl;
        }
    }
}