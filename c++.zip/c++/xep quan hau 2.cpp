#include <bits/stdc++.h>
using namespace std;

int val[8][8];
int a[8], MAX, sum = 0;

bool check(int x, int y)
{
    for (int i = 0; i < x; i++)
        if (a[i] == y || abs(i - x) == abs(a[i] - y))
            return false;
    return true;
}
void Try(int i, int n)
{
    for (int j = 0; j < n; j++)
    {
        if (check(i, j))
        {
            a[i] = j;
            sum += val[i][j];
            if (i == n - 1)
                MAX = max(MAX, sum);
            else
                Try(i + 1, n);
            sum -= val[i][j];
        }
    }
}

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        MAX = 0, sum = 0;
        memset(a, 0, sizeof(a));
        for (int i = 0; i < 8; i++)
            for (int j = 0; j < 8; j++)
                cin >> val[i][j];
        Try(0, 8);
        cout << MAX << endl;
    }
}