#include <bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        string s;
        cin >> s;
        int exp[s.length()];
        int count = 0;
        exp[count] = s[0] - '0';
        for (int i = 1; i < s.length(); i++)
        {
            count++;
            if ((s[i] == '1' && exp[count - 1] == 0) || (s[i] == '0' && exp[count - 1] == 1))
                exp[count] = 1;
            else if ((s[i] == '1' && exp[count - 1] == 1) || (s[i] == '0' && exp[count - 1] == 0))
                exp[count] = 0;
        }
        for (int i = 0; i <= count; i++)
            cout << exp[i];
        cout << endl;
    }
}