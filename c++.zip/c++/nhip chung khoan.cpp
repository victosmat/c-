#include <bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int n;
        cin >> n;
        int a[n + 1], val[n + 1];
        stack<int> pq;
        for (int i = 0; i < n; i++)
            cin >> a[i];
        pq.push(0);
        val[0] = 1;
        for (int i = 1; i < n; i++)
        {
            while (!pq.empty() && a[pq.top()] <= a[i])
                pq.pop();
            if (pq.empty())
                val[i] = (i + 1);
            else
                val[i] = i - pq.top();
            pq.push(i);
        }
        for (int i = 0; i < n; i++)
            cout << val[i] << " ";
        cout << endl;
    }
}