#include <bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int n;
        cin >> n;
        int f[n];
        int i2 = 0, i3 = 0, i5 = 0;
        int a = 2, b = 3, c = 5;
        int count = 1;
        f[0] = 1;
        for (int i = 1; i < n; i++)
        {
            count = min(a, min(b, c));
            f[i] = count;
            if (count == a)
            {
                i2 = i2 + 1;
                a = f[i2] * 2;
            }
            if (count == b)
            {
                i3 = i3 + 1;
                b = f[i3] * 3;
            }
            if (count == c)
            {
                i5 = i5 + 1;
                c = f[i5] * 5;
            }
        }
        cout << count << endl;
    }
}