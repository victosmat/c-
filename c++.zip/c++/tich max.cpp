#include <bits/stdc++.h>
using namespace std;

int main()
{

    int n;
    cin >> n;
    long long a[n];
    for (int i = 0; i < n; i++)
        cin >> a[i];
    sort(a, a + n);
    long long MAX = INT_MIN;
    MAX = max(MAX, a[0] * a[1]);
    MAX = max(MAX, a[n - 1] * a[n - 2]);
    MAX = max(MAX, a[0] * a[1] * a[2]);
    MAX = max(MAX, a[n - 1] * a[n - 2] * a[n - 3]);
    MAX = max(MAX, a[0] * a[1] * a[n - 1]);
    cout << MAX << endl;
}