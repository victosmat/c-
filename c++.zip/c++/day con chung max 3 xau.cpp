#include <bits/stdc++.h>
using namespace std;

int max(int a, int b, int c)
{
    a = max(a, b);
    return max(a, c);
}

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        string s1, s2, s3;
        int m, n, p;
        cin >> n >> m >> p;
        cin >> s1 >> s2 >> s3;
        int a[n + 1][m + 1][p + 1];
        memset(a, 0, sizeof a);
        for (int i = 1; i <= n; i++)
        {
            for (int j = 1; j <= m; j++)
            {
                for (int k = 1; k <= p; k++)
                {
                    if (s1[i - 1] == s2[j - 1] && s1[i - 1] == s3[k - 1])
                        a[i][j][k] = a[i - 1][j - 1][k - 1] + 1;
                    else
                        a[i][j][k] = max(max(a[i - 1][j][k], a[i][j - 1][k]), a[i][j][k - 1]);
                }
            }
        }
        cout << a[n][m][p] << endl;
    }
}