#include <bits/stdc++.h>
using namespace std;

#define ll long long
const long M = 1000000007;
map<long, long> F;

ll fibo(ll n)
{
    if (n == 0 || n == 1)
        return 1;
    long k = n / 2;
    if (n % 2 == 0)
        return F[n] = (fibo(k) * fibo(k) + fibo(k - 1) * fibo(k - 1)) % M;
    else
        return F[n] = (fibo(k) * fibo(k + 1) + fibo(k - 1) * fibo(k)) % M;
}

int main()
{
    ll n;
    F[0] = F[1] = 1;
    int t;
    cin >> t;
    while (t--)
    {
        cin >> n;
        cout << fibo(n - 1) << endl;
    }
}