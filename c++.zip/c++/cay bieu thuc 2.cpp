#include <bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int n;
        cin >> n;
        string s[n + 1];
        for (int i = 0; i < n; ++i)
            cin >> s[i];
        queue<int> q;
        for (int i = n - 1; i >= 0; i--)
        {
            if (s[i] == "+" || s[i] == "-" || s[i] == "*" || s[i] == "/")
            {
                int s1 = q.front();
                q.pop();
                int s2 = q.front();
                q.pop();
                int val;
                if (s[i] == "+")
                    val = s2 + s1;
                if (s[i] == "-")
                    val = s2 - s1;
                if (s[i] == "*")
                    val = s2 * s1;
                if (s[i] == "/")
                    val = s2 / s1;
                q.push(val);
            }
            else
                q.push(stoi(s[i]));
        }
        cout << q.front() << endl;
    }
}