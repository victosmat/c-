#include <bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int n, s;
        cin >> n >> s;
        int x, l[40005] = {0};
        l[0] = 1;
        for (int i = 1; i <= n; i++)
        {
            cin >> x;
            l[x] = 1;
            for (int j = s; j >= x; j--)
                if (l[j - x] == 1)
                    l[j] = 1;
        }
        if (l[s] == 1)
            cout << "YES" << endl;
        else
            cout << "NO" << endl;
    }
}