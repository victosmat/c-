#include <bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int n, m;
        cin >> n >> m;
        int a[n][m];
        for (int i = 0; i < n; i++)
            for (int j = 0; j < m; j++)
                cin >> a[i][j];
        int test = n + m - 2;
        vector<int> v(test);
        fill(v.begin(), v.end(), 0);
        fill(v.begin(), v.begin() + n - 1, 1);

        int count = 0;
        do
        {
            count++;
        } while (prev_permutation(v.begin(), v.end()));
        cout << count << endl;
    }
    return 0;
}