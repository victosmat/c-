#include <bits/stdc++.h>
using namespace std;

void in(int n, int a[])
{
    for (int i = 0; i < n; i++)
        cin >> a[i];
}

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int a, b, c;
        cin >> a >> b >> c;
        int A[a], B[b], C[c];
        in(a, A);
        in(b, B);
        in(c, C);
        int check = 0;
        int i = 0, j = 0, k = 0;
        while (i < a && j < b && k < c)
        {
            if (A[i] == B[j] && B[j] == C[k])
            {
                cout << A[i] << " ";
                i++, j++, k++;
                check = 1;
            }
            else if (A[i] < B[j])
                i++;
            else if (B[j] < C[k])
                j++;
            else
                k++;
        }
        if (!check)
        {
            cout << -1 << endl;
            continue;
        }
        cout << endl;
    }
}