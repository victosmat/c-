#include <bits/stdc++.h>
using namespace std;
int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int n;
        cin >> n;
        string a[n];
        for (int i = 0; i < n; i++)
            a[i] = 'A';
        for (int i = 0; i < n; i++)
            cout << a[i];
        cout << " ";
        for (int i = n - 1; i >= 0; i--)
        {
            if (a[i] == "A")
            {
                a[i] = 'B';
                for (int j = i + 1; j < n; j++)
                    a[j] = 'A';
                for (int i = 0; i < n; i++)
                    cout << a[i];
                cout << " ";
                i = n;
            }
        }
        cout << endl;
    }
}