#include <bits/stdc++.h>
using namespace std;

void sinh(string a[], int n, int i)
{
    if (i == n)
    {
        for (int i = 0; i < n; i++)
            cout << a[i];
        cout << " ";
        return;
    }
    a[i] = "6";
    sinh(a, n, i + 1);
    a[i] = "8";
    sinh(a, n, i + 1);
}

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int n;
        cin >> n;
        string a[n];
        int k = 1, count = 0;
        for (int i = 1; i <= n; i++)
            count += pow(2, i);
        cout << count << endl;
        while (k <= n)
        {
            sinh(a, k, 0);
            k++;
        }
        cout << endl;
    }
}