#include <bits/stdc++.h>
using namespace std;

typedef long long ll;

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int n;
        cin >> n;
        ll a[n + 1] = {};
        a[0] = a[1] = 1;
        for (int i = 2; i <= n; i++)
            for (int j = 0; j < i; j++)
                a[i] += a[j] * a[i - j - 1];
        cout << a[n] << endl;
    }
}