#include <bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        string s;
        cin >> s;
        stack<string> a;
        for (int i = 0; i < s.length(); i++)
        {
            if (s[i] == '*' || s[i] == '/' || s[i] == '+' || s[i] == '-')
            {
                string val_1 = a.top();
                a.pop();
                string val_2 = a.top();
                a.pop();
                string tmp = s[i] + val_2 + val_1;
                a.push(tmp);
            }
            else
                a.push(string(1, s[i]));
        }
        cout << a.top() << endl;
    }
}