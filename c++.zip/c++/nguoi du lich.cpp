#include <bits/stdc++.h>
using namespace std;

int n;
bool chuaxet[100];
long a[20][20], x[100], sum = 0;
long MIN = INT_MAX, cmin = INT_MAX;

void Try(int i)
{
    if (sum + cmin * (n - i + 1) >= MIN)
        return;
    for (int j = 1; j <= n; j++)
    {
        if (chuaxet[j])
        {
            x[i] = j;
            chuaxet[j] = false;
            sum += a[x[i - 1]][j];
            if (i == n)
                MIN = min(MIN, sum + a[x[n]][x[1]]);
            else
                Try(i + 1);
            sum -= a[x[i - 1]][j];
            chuaxet[j] = true;
        }
    }
}

int main()
{
    cin >> n;
    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= n; j++)
        {
            cin >> a[i][j];
            if (a[i][j] != 0)
                cmin = min(cmin, a[i][j]);
        }
    memset(chuaxet, true, sizeof chuaxet);
    chuaxet[1] = false;
    x[1] = 1;
    Try(2);
    cout << MIN << endl;
}