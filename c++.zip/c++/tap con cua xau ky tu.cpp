#include <bits/stdc++.h>
#define ll long long
using namespace std;

int main()
{

    int t;
    cin >> t;
    while (t--)
    {
        int n;
        cin >> n;
        string s;
        cin >> s;
        vector<string> str;
        for (int i = 1; i < pow(2, n); i++)
        {
            string x;
            for (int j = 0; j < n; j++)
                if (i & 1 << j)
                    x += s[j];
            str.push_back(x);
        }
        sort(str.begin(), str.end());
        for (int i = 0; i < str.size(); ++i)
            cout << str[i] << " ";
        cout << endl;
    }
}