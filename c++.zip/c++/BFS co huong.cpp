#include <bits/stdc++.h>
using namespace std;

vector<int> a[1005];
bool chuaxet[1005];
long v, e, u;
int x, y;

void BFS(int u)
{
    queue<int> pq;
    chuaxet[u] = false;
    pq.push(u);
    while (!pq.empty())
    {
        int s = pq.front();
        pq.pop();
        cout << s << " ";
        for (int i = 0; i < a[s].size(); i++)
        {
            if (chuaxet[a[s][i]])
            {
                pq.push(a[s][i]);
                chuaxet[a[s][i]] = false;
            }
        }
    }
}

void init()
{
    for (int i = 1; i <= v; i++)
        chuaxet[i] = true;
    for (int i = 1; i <= v; i++)
        a[i].clear();
}

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        cin >> v >> e >> u;
        init();
        for (long i = 0; i < e; i++)
        {
            cin >> x >> y;
            a[x].push_back(y);
        }
        BFS(u);
        cout << endl;
    }
}