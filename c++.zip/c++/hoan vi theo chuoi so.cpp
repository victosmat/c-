#include <bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int n;
        cin >> n;
        string str;
        cin >> str;
        int a[81];
        int s = str.length();
        for (int i = 0; i < s; i++)
            a[i] = str[i] - '0';
        cout << n << " ";
        int val = next_permutation(a, a + s);
        if (val == false)
            cout << "BIGGEST" << endl;
        else
            for (int i = 0; i < s; i++)
                cout << a[i];
        cout << endl;
    }
}