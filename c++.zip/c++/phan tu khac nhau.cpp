#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        ll n;
        cin >> n;
        ll a[n], b[n - 1];
        for (ll i = 0; i < n; i++)
            cin >> a[i];
        for (ll i = 0; i < n - 1; i++)
            cin >> b[i];
        ll i = 0, j = 0, cnt = 0;
        while (i < n && j < n - 1)
        {
            if (a[i] == b[j])
                i++, j++, cnt++;
            else
            {
                cout << cnt + 1 << endl;
                break;
            }
        }
    }
}