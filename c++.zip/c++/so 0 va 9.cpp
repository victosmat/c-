#include <bits/stdc++.h>
using namespace std;

vector<string> a;

void duyet()
{
    queue<string> pq;
    pq.push("9");
    for (int i = 0; i < 10000; i++)
    {
        string s1 = pq.front();
        pq.pop();
        a.push_back(s1);
        string s2 = s1;
        pq.push(s1 + '0');
        pq.push(s2 + '9');
    }
}

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        duyet();
        int n;
        cin >> n;
        for (int i = 0; i < a.size(); i++)
            cout << a[i] << " ";
    }
}