#include <bits/stdc++.h>
using namespace std;

int check(string a[], int n)
{
    if (a[0] == "A" || a[n - 1] == "H")
        return 0;
    for (int i = 0; i < n; i++)
        if (a[i] == "H" && a[i + 1] == "H")
            return 0;
    return 1;
}

void sinh(string a[], int n, int i)
{
    if (i == n)
    {
        if (check(a, n))
        {
            for (int i = 0; i < n; i++)
                cout << a[i];
            cout << endl;
        }
        return;
    }
    a[i] = 'A';
    sinh(a, n, i + 1);
    a[i] = 'H';
    sinh(a, n, i + 1);
}

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int n;
        cin >> n;
        string a[n];
        sinh(a, n, 0);
    }
}