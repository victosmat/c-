#include <bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        string s;
        int a, b, c;
        cin >> s;
        int cnt = 1;
        for (int i = 0; i < s.length(); i++)
        {
            a = b = i;
            while (a >= 0 && b < s.length())
            {
                if (s[a] == s[b])
                {
                    cnt = max(cnt, b - a + 1);
                    a--, b++;
                }
                else
                    break;
            }
            a = i, c = i + 1;
            while (a >= 0 && c < s.length())
            {
                if (s[a] == s[c])
                {
                    cnt = max(cnt, c - a + 1);
                    a--, c++;
                }
                else
                    break;
            }
        }
        cout << cnt << endl;
    }
}