#include <bits/stdc++.h>
using namespace std;

void duyet(int n)
{
    queue<string> pq;
    pq.push("9");
    while (1)
    {
        string s1 = pq.front();
        pq.pop();
        long long sum = 0;
        for (int i = 0; i < s1.length(); i++)
            sum = sum * 10 + (s1[i] - '0');
        if (sum % n == 0)
        {
            cout << sum << endl;
            return;
        }
        else
        {
            string s2 = s1;
            pq.push(s1 + '0');
            pq.push(s2 + '9');
        }
    }
}

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int n;
        cin >> n;
        duyet(n);
    }
}