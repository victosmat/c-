//Xây dựng cây bao trùm bé nhất theo Kruskal
#include <bits/stdc++.h>
using namespace std;
struct canh
{
    int dau, cuoi, id;
};
canh DS_canh[1000], T[1000];
int n, a[100][100], chuaxet[100], dH;
int k = 0; // so canh DS_canh(so phan tu cua DS_canh)
int v = 0; //so canh cua T(so phan tu cua T);
bool idTangDan(canh x, canh y)
{
    return x.id < y.id;
}
void recursiveDFS(int u)
{
    chuaxet[u] = false;
    for (int i = 1; i <= n; i++)
        if (a[u][i] && chuaxet[i])
            recursiveDFS(i);
}
void init()
{
    for (int i = 1; i <= n; i++)
        chuaxet[i] = true;
}
void Kruskal()
{
    int z = 0;
    for (int i = 0; i < k; i++)
    {
        int x = DS_canh[i].dau;
        int y = DS_canh[i].cuoi;
        recursiveDFS(x);
        if (chuaxet[y])
        {
            a[x][y] = 1;
            a[y][x] = 1;
            dH += DS_canh[i].id;
            T[v] = DS_canh[i];
            ++v;
        }
        init();
    }
}
int main()
{
    //read data
    cin >> n;
    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= n; j++)
        {
            int x;
            cin >> x;
            if (x > 0 && i < j)
            {
                DS_canh[k].dau = i;
                DS_canh[k].cuoi = j;
                DS_canh[k].id = x;
                ++k;
            }
        }
    init();
    //sort id tang dan
    stable_sort(DS_canh, DS_canh + k, idTangDan);
    Kruskal();
    cout << "dH = " << dH << endl;
    for (int i = 0; i < v; i++)
        cout << T[i].dau << " " << T[i].cuoi << endl;
}