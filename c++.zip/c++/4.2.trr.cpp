//Tìm chu trình Hamilton
#include <bits/stdc++.h>
#define MAX 100
using namespace std;

class dothi
{
    int n, a[MAX][MAX];

public:
    int s, x[100];
    bool chuaxet[MAX];
    void readData();
    void init();
    void hmt(int k);
};
void dothi::readData()
{
    cin >> n >> s;
    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= n; j++)
            cin >> a[i][j];
}
void dothi::init()
{
    for (int i = 1; i <= n; i++)
        chuaxet[i] = true;
}
void dothi::hmt(int k)
{
    for (int y = 1; y <= n; y++)
        if (a[x[k - 1]][y] == 1)
        {
            if ((k == n + 1) && (y == x[1]))
            {
                for (int i = 1; i <= n; i++)
                    cout << x[i] << " ";
                cout << x[1] << endl;
            }
            else
            {
                if (chuaxet[y] == true)
                {
                    x[k] = y;
                    chuaxet[y] = false;
                    hmt(k + 1);
                    chuaxet[y] = true;
                }
            }
        }
}

int main()
{
    dothi g;
    g.readData();
    g.x[1] = g.s;
    g.init();
    g.chuaxet[g.s] = false;
    g.hmt(2);
}