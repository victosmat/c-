#include <bits/stdc++.h>
using namespace std;

long long a[100];

string test(int n, long long k)
{
    if (n == 1)
        return "0";
    if (n == 2)
        return "1";
    if (k <= a[n - 2])
        return test(n - 2, k);
    return test(n - 1, k - a[n - 2]);
}

int main()
{
    a[1] = 1;
    a[2] = 1;
    for (int i = 3; i < 93; i++)
        a[i] = a[i - 1] + a[i - 2];
    int t;
    cin >> t;
    while (t--)
    {
        int n;
        long long i;
        cin >> n >> i;
        cout << test(n, i) << endl;
    }
}