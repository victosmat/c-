#include <bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        string s;
        cin >> s;
        stack<string> pq;
        int count = 0;
        for (int i = 0; i < s.length(); i++)
        {
            if (s[i] == '(')
                pq.push(string(1, s[i]));
            else
            {
                if (!pq.empty())
                {
                    pq.pop();
                    count += 2;
                }
            }
        }
        cout << count << endl;
    }
}