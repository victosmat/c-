#include <iostream>
#include <vector>
using namespace std;

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int n;
        long long k;
        cin >> n >> k;
        vector<long> a(n);
        for (int i = 0; i < n; i++)
            cin >> a[i];
        bool check = false;
        int i = 1, j = 0;
        long long sum = a[0];
        while (i <= n)
        {
            if (sum < k || i == j)
                sum += a[i++];
            else if (sum > k)
                sum -= a[j++];
            else
            {
                check = true;
                cout << "YES" << endl;
                break;
            }
        }
        if (!check)
            cout << "NO" << endl;
    }
}