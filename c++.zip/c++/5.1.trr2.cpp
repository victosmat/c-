//cây bao trùm BFS và DFS
#include <bits/stdc++.h>
using namespace std;

struct edg
{
    int dau, cuoi;
};

class dothi
{
    int n, a[100][100];

public:
    int net, s;
    edg tree[100];
    bool chuaxet[100];
    void readdata();
    void init();
    void dfstree(int u);
    void bfstree(int u);
};

void dothi::readdata()
{
    cin >> n >> s;
    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= n; j++)
            cin >> a[i][j];
}

void dothi::init()
{
    for (int i = 1; i <= n; i++)
    {
        chuaxet[i] = true;
        net = 0; //số cạnh bằng 0
    }
}

void dothi::dfstree(int u)
{
    chuaxet[u] = false;
    for (int v = 1; v <= n; v++)
        if (a[u][v] == 1 && chuaxet[v] == true)
        {
            if (u < v)
            {
                net++; //tăng số cạnh
                tree[net].dau = u;
                tree[net].cuoi = v;
            }
            else
            {
                net++; //tăng số cạnh
                tree[net].dau = v;
                tree[net].cuoi = u;
            }
            dfstree(v);
        }
}

void dothi::bfstree(int u)
{
    queue<int> hangdoi;
    hangdoi.push(u);
    chuaxet[u] = false;
    while (!hangdoi.empty())
    {
        int s = hangdoi.front();
        hangdoi.pop();
        for (int i = 1; i <= n; i++)
            if (a[s][i] == 1 && chuaxet[i] == true)
            {
                if (s < i)
                {
                    net++; //tăng số cạnh
                    tree[net].dau = s;
                    tree[net].cuoi = i;
                }
                else
                {
                    net++; //tăng số cạnh
                    tree[net].dau = i;
                    tree[net].cuoi = s;
                }
                hangdoi.push(i);
                chuaxet[i] = false;
            }
    }
}

int main()
{
    dothi g;
    g.readdata();
    g.init();
    g.dfstree(g.s);
    cout << "DFS tree" << endl;
    for (int i = 1; i <= g.net; i++)
        cout << g.tree[i].dau << " " << g.tree[i].cuoi << endl;
    g.init();
    g.bfstree(g.s);
    cout << "BFS tree" << endl;
    for (int i = 1; i <= g.net; i++)
        cout << g.tree[i].dau << " " << g.tree[i].cuoi << endl;
}