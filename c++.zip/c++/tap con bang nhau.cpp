#include <bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int n;
        cin >> n;
        int a[n], sum = 0;
        for (int i = 0; i < n; i++)
        {
            cin >> a[i];
            sum += a[i];
        }
        if (sum % 2 != 0)
        {
            cout << "NO" << endl;
            continue;
        }
        int b[sum + 1];
        for (int i = 0; i < n; i++)
            for (int j = sum; j >= a[i]; j--)
                if (b[j - a[i]])
                    b[j] = 1;
        if (b[sum])
            cout << "YES" << endl;
        else
            cout << "NO" << endl;
    }
}