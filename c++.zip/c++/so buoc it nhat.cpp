#include <bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int n;
        cin >> n;
        int a[n], f[n];
        for (int i = 0; i < n; i++)
            cin >> a[i];
        int test = 1;
        for (int i = 0; i < n; i++)
        {
            f[i] = 0;
            for (int j = i - 1; j >= 0; j--)
                if (a[i] >= a[j])
                    f[i] = max(f[i], f[j]);
            f[i] += 1;
            test = max(test, f[i]);
        }
        cout << n - test << endl;
    }
}