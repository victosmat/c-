#include <bits/stdc++.h>
using namespace std;

void in(int n, int a[])
{
    for (int i = 0; i < n; i++)
        cin >> a[i];
}

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int a, b, c;
        cin >> a >> b >> c;
        int A[a], B[b], C[c];
        in(a, A);
        in(b, B);
        in(c, C);
        int i = 0, j = 0;
        int ck1[max(a, max(b, c))];
        int cnt1 = 0;
        while (i < a && j < b)
        {
            if (A[i] < B[j])
                i++;
            else if (B[j] < A[i])
                j++;
            else if (A[i] == B[j])
            {
                ck1[cnt1++] = A[i];
                i++, j++;
            }
        }
        if (!cnt1)
        {
            cout << "NO" << endl;
            continue;
        }
        i = 0, j = 0;
        int check = 0;
        while (i < cnt1 && j < c)
        {
            if (ck1[i] < C[j])
                i++;
            else if (C[j] < ck1[i])
                j++;
            else if (ck1[i] == C[j])
            {
                check = 1;
                cout << ck1[i] << " ";
                i++, j++;
            }
        }
        if (!check)
        {
            cout << "NO" << endl;
            continue;
        }
        cout << endl;
    }
}