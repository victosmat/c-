#include <bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        string s;
        int n, a[26] = {0};
        cin >> n >> s;
        int MAX = 0;
        for (int i = 0; i < s.length(); i++)
        {
            a[s[i] - 'A']++;
            MAX = max(MAX, a[s[i] - 'A']);
        }
        if ((MAX - 1) * (n - 1) + MAX > s.length())
            cout << -1 << endl;
        else
            cout << 1 << endl;
    }
}