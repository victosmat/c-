#include <bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int n, a, b;
        cin >> n;
        int arr[n + 5] = {0};
        int val = 0;
        for (int i = 1; i < n; i++)
        {
            cin >> a >> b;
            arr[b] = arr[a] + 1;
            val = max(val, arr[b]);
        }
        cout << val << endl;
    }
}