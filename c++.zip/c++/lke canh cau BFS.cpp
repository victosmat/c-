#include <bits/stdc++.h>
using namespace std;

int v, e, x, y;
vector<int> a[1005];
int chuaxet[1005];

void BFS(int u)
{
    queue<int> pq;
    chuaxet[u] = false;
    pq.push(u);
    while (!pq.empty())
    {
        int s = pq.front();
        pq.pop();
        for (int i = 0; i < a[s].size(); i++)
        {
            if (chuaxet[a[s][i]])
            {
                pq.push(a[s][i]);
                chuaxet[a[s][i]] = false;
            }
        }
    }
}

void init()
{
    for (int i = 1; i <= v; i++)
        chuaxet[i] = true;
    for (int i = 1; i <= v; i++)
        a[i].clear();
}

void CanhCau()
{
    for (int i = 1; i <= v; i++)
    {
        for (int j = 0; j < a[i].size(); j++)
        {
            if (i > a[i][j])
                continue;
            for (int i = 1; i <= v; i++)
                chuaxet[i] = true;
            int val_1 = a[i][j];
            int b, val_2;
            for (int k = 0; k < a[a[i][j]].size(); k++)
                if (a[a[i][j]][k] == i)
                {
                    b = k;
                    val_2 = a[a[i][j]][k];
                    a[a[i][j]][k] = 0;
                }
            a[i][j] = 0;
            BFS(1);
            for (int h = 1; h <= v; h++)
                if (chuaxet[h])
                {
                    cout << i << " " << val_1 << " ";
                    break;
                }
            a[i][j] = val_1;
            a[a[i][j]][b] = val_2;
        }
    }
}

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        cin >> v >> e;
        init();
        for (int i = 1; i <= e; i++)
        {
            cin >> x >> y;
            a[x].push_back(y);
            a[y].push_back(x);
        }
        CanhCau();
        cout << endl;
    }
}