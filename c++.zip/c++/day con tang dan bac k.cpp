#include <bits/stdc++.h>
using namespace std;

int a[100], n, k, val[100];
int cnt;

bool check(int val[], int a[], int k)
{
    for (int i = 1; i <= k; i++)
        if (val[a[i]] > val[a[i + 1]])
            return false;
    return true;
}

void Try(int i)
{
    for (int j = a[i - 1] + 1; j <= n - k + i; j++)
    {
        a[i] = j;
        if (i == k)
        {
            if (val[a[k - 1]] > val[a[k - 2]] && val[a[k - 1]] < val[a[k]])
                cnt++;
        }
        else
            Try(i + 1);
    }
}

int main()
{
    cin >> n >> k;
    for (int i = 1; i <= n; i++)
        cin >> val[i];
    cnt = 0;
    Try(1);
    cout << cnt << endl;
}