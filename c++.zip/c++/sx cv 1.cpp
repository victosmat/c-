#include <bits/stdc++.h>
using namespace std;

int n, a[1005], b[1005];

void sort_(int a[], int b[], int n)
{
    for (int i = 1; i < n; i++)
        for (int j = 0; j < i; j++)

            if (b[j] > b[i])
            {
                swap(b[i], b[j]);
                swap(a[i], a[j]);
            }
}

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        cin >> n;
        for (int i = 0; i < n; i++)
            cin >> a[i];
        for (int i = 0; i < n; i++)
            cin >> b[i];
        sort_(a, b, n);
        int val = 1, tmp = 0;
        for (int i = 1; i < n; i++)
        {
            if (a[i] >= b[tmp])
            {
                val++;
                tmp = i;
            }
        }
        cout << val << endl;
    }
}