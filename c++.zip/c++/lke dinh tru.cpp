#include <bits/stdc++.h>
using namespace std;

int v, e, x, y;
vector<int> a[1005];
int chuaxet[1005];

void DFS(int u)
{
    chuaxet[u] = false;
    for (int i = 0; i < a[u].size(); i++)
        if (chuaxet[a[u][i]])
            DFS(a[u][i]);
}

void init()
{
    for (int i = 1; i <= v; i++)
        chuaxet[i] = true;
    for (int i = 1; i <= v; i++)
        a[i].clear();
}

void DinhTru()
{
    for (int i = 1; i <= v; i++)
    {
        chuaxet[i] = false;
        if (i < v)
            DFS(i + 1);
        else if (i == v)
            DFS(i - 1);
        for (int j = 0; j < a[i].size(); j++)
        {
            if (chuaxet[a[i][j]])
            {
                cout << i << " ";
                break;
            }
        }
        for (int k = 0; k <= v; k++)
            chuaxet[k] = true;
    }
}

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        cin >> v >> e;
        init();
        for (int i = 1; i <= e; i++)
        {
            cin >> x >> y;
            a[x].push_back(y);
            a[y].push_back(x);
        }
        DinhTru();
        cout << endl;
    }
}