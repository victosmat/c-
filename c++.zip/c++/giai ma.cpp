#include <bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        string str;
        cin >> str;
        if (str[0] == '0')
        {
            cout << 0 << endl;
            continue;
        }
        int count = 1;
        int test1 = 1, test2 = 1;
        bool check = true;
        for (int i = str.length() - 1; i >= 0; i--)
        {
            if (str[i] == '0' && (str[i - 1] > '2' || str[i - 1] == '0'))
            {
                cout << 0 << endl;
                check = false;
                break;
            }
            else if (str[i] == '0' && str[i - 1] <= '2')
            {
                str[i - 1] = '-1';
                i -= 1;
                test2 = 0;
                continue;
            }
            if (i < str.length() - 1)
            {
                int val;
                if (str[i + 1] == '-1')
                    val = str[i] - '0';
                else
                    val = str[i + 1] - '0' + (str[i] - '0') * 10;
                if (val <= 26)
                    count += test2;
            }
            test2 = test1;
            test1 = count;
        }
        if (check)
            cout << count << endl;
    }
}