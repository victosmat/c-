#include <bits/stdc++.h>
using namespace std;

long n, k, a[35];
vector<long> lenv;
bool check;
void backtrack(long sum, long l, vector<long> &v)
{
    if (sum == k)
    {
        lenv.push_back(v.size());
        check = true;
    }
    else
        for (int i = l; i < n; i++)
            if (sum + a[i] <= k)
            {
                v.push_back(a[i]);
                backtrack(sum + a[i], i + 1, v);
                v.pop_back();
            }
}
int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        lenv.clear();
        check = false;
        cin >> n >> k;
        for (int i = 0; i < n; i++)
            cin >> a[i];
        vector<long> v;
        sort(a, a + n);
        backtrack(0, 0, v);
        (check) ? cout << *min_element(lenv.begin(), lenv.end()) << endl : cout << -1 << endl;
    }
}