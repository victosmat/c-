#include <bits/stdc++.h>
using namespace std;

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        long long n;
        cin >> n;
        queue<string> pq;
        pq.push("1");
        long long cnt = 0;
        while (true)
        {
            string s1 = pq.front();
            string s2 = s1;
            pq.pop();
            long long sum = 0;
            for (long long i = 0; i < s1.length(); i++)
                sum = sum * 10 + (s1[i] - '0');
            if (sum > n)
                break;
            else
            {
                pq.push(s1.append("0"));
                pq.push(s2.append("1"));
            }
            cnt++;
        }
        cout << cnt << endl;
    }
}