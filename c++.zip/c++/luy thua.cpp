#include <bits/stdc++.h>
using namespace std;
#define e 1000000007

long long check(int a, long long b)
{
    if (b == 0)
        return 1;
    if (b == 1)
        return a;
    else
    {
        long long p = check(a, b / 2);
        p %= e;
        if (b % 2 == 0)
            return (p * p) % e;
        else
            return (((p * p) % e) * a) % e;
    }
}
int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        long long a, b;
        cin >> a >> b;
        if (a == 0 && b == 0)
            continue;
        long long test = check(a, b);
        cout << test << endl;
    }
}