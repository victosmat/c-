#include <bits/stdc++.h>
using namespace std;

int val[10], a[100][100], sum;
vector<vector<int>> vec;

void test(int n, int k)
{
    do
    {
        vector<int> v;
        int sum = 0;
        for (int i = 0; i < n; i++)
            sum += a[i][val[i]];
        if (sum == k)
        {
            for (int i = 0; i < n; i++)
                v.push_back(val[i]);
            vec.push_back(v);
        }
    } while (next_permutation(val, val + n));
}

int main()
{
    int n, k;
    cin >> n >> k;
    for (int i = 0; i < n; i++)
        val[i] = i;
    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++)
            cin >> a[i][j];
    test(n, k);
    cout << vec.size() << endl;
    for (int i = 0; i < vec.size(); i++)
    {
        for (int j = 0; j < vec[i].size(); j++)
            cout << vec[i][j] + 1 << " ";
        cout << endl;
    }
}