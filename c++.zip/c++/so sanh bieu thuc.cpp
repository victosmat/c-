#include <bits/stdc++.h>
using namespace std;

string check(string s)
{
    stack<int> a;
    for (int i = 0; i < s.length(); i++)
    {
        if (s[i] == '(')
            a.push(i);
        else if (s[i] == ')')
        {
            int val = a.top();
            a.pop();
            if (val == 0)
                continue;
            else if (s[val - 1] == '+')
                continue;
            else if (s[val - 1] == '-')
            {
                for (int j = val + 1; j < i; j++)
                    if (s[j] == '+')
                        s[j] = '-';
                    else if (s[j] == '-')
                        s[j] = '+';
            }
        }
    }
    string S = "";
    for (int i = 0; i < s.length(); i++)
        if (s[i] != '(' && s[i] != ')')
            S += s[i];
    return S;
}

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        string s1, s2;
        cin >> s1 >> s2;
        (check(s1).compare(check(s2)) == 0) ? cout << "YES" << endl : cout << "NO" << endl;
    }
}
