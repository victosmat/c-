#include <bits/stdc++.h>
using namespace std;
int a[11][11], n, test;
char c[100];
void Try(int i, int j, int k)
{
    if (i == n - 1 && j == n - 1)
    {
        for (int i = 0; i < k; ++i)
            cout << c[i];
        cout << " ";
        test++;
        return;
    }
    if (i < n && a[i + 1][j] == 1)
    {
        c[k] = 'D';
        a[i + 1][j] = 0;
        Try(i + 1, j, k + 1);
        a[i + 1][j] = 1;
    }
    if (j < n and a[i][j + 1] == 1)
    {
        c[k] = 'R';
        a[i][j + 1] = 0;
        Try(i, j + 1, k + 1);
        a[i][j + 1] = 1;
    }
}
int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        cin >> n;
        test = 0;
        for (int i = 0; i < n; ++i)
            for (int j = 0; j < n; ++j)
                cin >> a[i][j];
        if (a[0][0] == 1 && a[n - 1][n - 1] == 1)
            Try(0, 0, 0);
        if (test)
            cout << endl;
        else
            cout << -1 << endl;
    }
}