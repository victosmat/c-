#include <bits/stdc++.h>
using namespace std;

struct p
{
    bool node = false;
    int val = 0;
    int left = -1;
    int right = -1;
};

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int n;
        cin >> n;
        unordered_map<int, p> m;
        int high = 0;
        for (int i = 0; i < n; i++)
        {
            int a, b;
            char c;
            cin >> a >> b >> c;
            if (c == 'L')
                m[a].left = b;
            else
                m[a].right = b;
            m[b].val = m[a].val + 1;
            high = max(high, m[b].val);
            m[b].node = true;
        }
        bool check = true;
        for (int i = 0; i < m.size(); i++)
            if (m[i].left != -1 && m[i].right == -1 || m[i].left == -1 && m[i].right != -1)
                check = false;
        for (int i = 0; i < m.size(); i++)
            if (m[i].left == -1 && m[i].right == -1 && m[i].node && m[i].val != high)
                check = false;
        (check) ? cout << "Yes" << endl : cout << "No" << endl;
    }
}