#include <bits/stdc++.h>
using namespace std;

int main()
{
    int n, val;
    cin >> n;
    bool a[1005][1005];
    getchar();
    for (int i = 1; i <= n; i++)
    {
        string S;
        getline(cin, S);
        istringstream ss(S);
        while (ss >> val)
            a[i][val] = a[val][i] = 1;
    }
    for (int i = 1; i <= n; i++)
    {
        for (int j = 1; j <= n; j++)
        {
            if (a[i][j] != 1)
                cout << 0 << " ";
            else
                cout << a[i][j] << " ";
        }
        cout << endl;
    }
}