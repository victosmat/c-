#include <bits/stdc++.h>
using namespace std;

struct p
{
    int val = 0;
    int left = -1;
    int right = -1;
};

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        int n;
        cin >> n;
        unordered_map<int, p> m;
        for (int i = 0; i < n; i++)
        {
            int a, b;
            char c;
            cin >> a >> b >> c;
            if (c == 'L')
                m[a].left = b;
            else
                m[a].right = b;
        }
        bool check = true;
        for (int i = 0; i < m.size(); i++)
            if (m[i].left != -1 && m[i].right == -1 || m[i].left == -1 && m[i].right != -1)
                check = false;
        (check) ? cout << "1" << endl : cout << "0" << endl;
    }
}