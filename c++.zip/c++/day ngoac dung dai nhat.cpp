#include <bits/stdc++.h>
using namespace std;
#define ll long long

ll sum, maxS;
string s;

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        cin >> s;
        if (!s.length())
        {
            cout << 1 << endl;
            continue;
        }
        sum = maxS = 0;
        stack<int> q;
        for (int i = 0; i < s.length(); i++)
        {
            if (s[i] == '(')
                q.push(1);
            else
            {
                sum = 0;
                while (!q.empty() && q.top() > 1)
                {
                    sum += q.top();
                    q.pop();
                }
                if (!q.empty() && q.top() == 1)
                {
                    q.pop();
                    sum += 2;
                    while (!q.empty() && q.top() > 1)
                    {
                        sum += q.top();
                        q.pop();
                    }
                    q.push(sum);
                }
                else
                    q.push(0);
                maxS = max(sum, maxS);
            }
        }
        cout << maxS << endl;
    }
}