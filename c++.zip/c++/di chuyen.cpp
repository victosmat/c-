#include <bits/stdc++.h>
using namespace std;

int n, check;
vector<string> a;
int arr[10][10];

void Try(int i, int j, string s)
{
    if (i == 0 && j == 0 && arr[i][j] == 0)
        return;
    if (i == n - 1 && j == n - 1 && arr[i][j] == 1)
    {
        a.push_back(s);
        check = 1;
        return;
    }
    if (j < n - 1 && arr[i][j + 1] == 1)
        Try(i, j + 1, s + "R");
    if (i < n - 1 && arr[i + 1][j] == 1)
        Try(i + 1, j, s + "D");
}

int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        cin >> n;
        for (int i = 0; i < n; i++)
            for (int j = 0; j < n; j++)
                cin >> arr[i][j];
        check = 0;
        a.clear();
        Try(0, 0, "");
        if (check == 0)
        {
            cout << -1 << endl;
            continue;
        }
        sort(a.begin(), a.end());
        for (int i = 0; i < a.size(); i++)
            cout << a[i] << " ";
        cout << endl;
    }
}